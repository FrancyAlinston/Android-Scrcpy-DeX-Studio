#!/usr/bin/env bash
set -e
APP_DIR="/opt/android-scrcpy-dex-studio"
VENV_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/android-scrcpy-dex-studio/venv"

if python3 -c "import customtkinter, psutil, PIL" >/dev/null 2>&1; then
    exec python3 "$APP_DIR/adb_scrcpy_studio.py" "$@"
fi

if [ ! -x "$VENV_DIR/bin/python" ]; then
    mkdir -p "$(dirname "$VENV_DIR")"
    python3 -m venv "$VENV_DIR"
    "$VENV_DIR/bin/pip" install --upgrade pip customtkinter psutil pillow >/dev/null 2>&1
fi

exec "$VENV_DIR/bin/python" "$APP_DIR/adb_scrcpy_studio.py" "$@"
