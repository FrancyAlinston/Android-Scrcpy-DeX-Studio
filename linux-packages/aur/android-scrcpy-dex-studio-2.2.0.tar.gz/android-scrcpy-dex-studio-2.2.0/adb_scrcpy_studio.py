#!/usr/bin/env python3
"""
J.A.R.V.I.S. Android & Scrcpy DeX Studio v2.1
Self-Contained Multi-Platform Android Control, Live Task Manager, Scrcpy Mirror & DeX Workstation
Features:
 - Magnetic Android Emulator Side-Toolbar (`ScrcpyEmulatorSideBar`) attached directly alongside the Scrcpy Mirror window!
 - Tracks Scrcpy window position/resize/minimize at 60fps via Win32 ctypes (GetWindowRect / EnumWindows) & Linux xdotool/xprop
 - 4x Supersampled Vector Icons & Symbols rendered on the fly via Pillow
 - 60fps Animated Telemetry Gauges, Smooth Cubic-Bezier Tab Transitions & Pulse Animations
 - Self-Contained Embedded ADB & Scrcpy 4.0 Runtime (works as a single portable --onefile EXE anywhere)
"""

import os
import sys

# Windowed mode standard stream guards (PyInstaller --windowed safety)
if sys.stdout is None:
    try:
        sys.stdout = open(os.devnull, "w")
    except Exception:
        pass
if sys.stderr is None:
    try:
        sys.stderr = open(os.devnull, "w")
    except Exception:
        pass

import re
import math
import time
import json
import ctypes
import shutil
import threading
import subprocess
from collections import deque
from typing import Dict, List, Optional, Tuple, Any, Callable
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import psutil
from PIL import Image, ImageDraw
import customtkinter as ctk

# Configure Dark Obsidian theme
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0
APP_VERSION = "2.2.0"


def get_bundle_dir() -> str:
    """Return PyInstaller _MEIPASS bundle extraction root or script directory."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return getattr(sys, "_MEIPASS")
    return os.path.dirname(os.path.abspath(__file__))


def get_subprocess_kwargs() -> Dict[str, Any]:
    """Return cross-platform subprocess arguments enforcing Rule #4 (CREATE_NO_WINDOW & SW_HIDE)."""
    kwargs: Dict[str, Any] = {}
    if os.name == "nt":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0  # SW_HIDE
        kwargs["startupinfo"] = startupinfo
        kwargs["creationflags"] = CREATE_NO_WINDOW
    return kwargs


def resolve_binary(bin_name: str, win_fallbacks: List[str], linux_fallbacks: List[str]) -> str:
    """Resolve binary executable path prioritizing embedded self-contained bundle first."""
    bundle_root = get_bundle_dir()
    exe_ext = ".exe" if os.name == "nt" else ""
    bundled_candidate = os.path.join(bundle_root, "bundled_bins", f"{bin_name}{exe_ext}")
    if os.path.isfile(bundled_candidate):
        return bundled_candidate

    local_candidate = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bundled_bins", f"{bin_name}{exe_ext}")
    if os.path.isfile(local_candidate):
        return local_candidate

    found = shutil.which(bin_name)
    if found:
        return found

    candidates = win_fallbacks if os.name == "nt" else linux_fallbacks
    for path in candidates:
        expanded = os.path.expandvars(os.path.expanduser(path))
        if os.path.isfile(expanded):
            return expanded
    return bin_name


ADB_BIN = resolve_binary(
    "adb",
    [
        r"C:\Users\franc\adb.exe",
        r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\Google.PlatformTools_Microsoft.Winget.Source_8wekyb3d8bbwe\platform-tools\adb.exe",
        r"%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe",
    ],
    ["/usr/bin/adb", "/usr/local/bin/adb", "~/Android/Sdk/platform-tools/adb"],
)

SCRCPY_BIN = resolve_binary(
    "scrcpy",
    [
        r"C:\Users\franc\scrcpy.exe",
        r"%USERPROFILE%\scrcpy.exe",
        r"%LOCALAPPDATA%\Microsoft\WinGet\Links\scrcpy.exe",
        r"C:\Program Files\scrcpy\scrcpy.exe",
    ],
    ["/usr/bin/scrcpy", "/usr/local/bin/scrcpy"],
)


def find_window_rect_by_title(title_sub: str) -> Optional[Tuple[int, int, int, int, bool]]:
    """
    Locate a native OS window matching `title_sub` and return (left, top, right, bottom, is_minimized).
    Uses Win32 user32 ctypes on Windows and xdotool on Linux.
    """
    if os.name == "nt":
        user32 = ctypes.windll.user32
        found_rect: List[Tuple[int, int, int, int, bool]] = []

        class RECT(ctypes.Structure):
            _fields_ = [
                ("left", ctypes.c_long),
                ("top", ctypes.c_long),
                ("right", ctypes.c_long),
                ("bottom", ctypes.c_long),
            ]

        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def enum_cb(hwnd: int, _lparam: int) -> bool:
            if not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            if title_sub.lower() in buf.value.lower():
                rc = RECT()
                if user32.GetWindowRect(hwnd, ctypes.byref(rc)):
                    is_min = bool(user32.IsIconic(hwnd))
                    found_rect.append((rc.left, rc.top, rc.right, rc.bottom, is_min))
                    return False
            return True

        user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
        return found_rect[0] if found_rect else None
    else:
        # Linux X11 / XWayland window geometry lookup via xdotool
        try:
            proc = subprocess.run(
                ["xdotool", "search", "--name", title_sub],
                capture_output=True,
                text=True,
                timeout=0.4,
            )
            if proc.returncode == 0 and proc.stdout.strip():
                wid = proc.stdout.strip().splitlines()[0]
                gproc = subprocess.run(
                    ["xdotool", "getwindowgeometry", "--shell", wid],
                    capture_output=True,
                    text=True,
                    timeout=0.4,
                )
                if gproc.returncode == 0:
                    kv = {}
                    for line in gproc.stdout.splitlines():
                        if "=" in line:
                            k, v = line.split("=", 1)
                            kv[k.strip()] = int(v.strip())
                    x, y = kv.get("X", 100), kv.get("Y", 100)
                    w, h = kv.get("WIDTH", 400), kv.get("HEIGHT", 800)
                    return (x, y, x + w, y + h, False)
        except Exception:
            pass
        return None


class ModernVectorIconFactory:
    """Renders 4x supersampled anti-aliased vector icons into CTkImage objects at runtime."""

    def __init__(self) -> None:
        self._cache: Dict[str, ctk.CTkImage] = {}

    def get(self, name: str, size: int = 20, color: Tuple[int, int, int, int] = (56, 189, 248, 255)) -> ctk.CTkImage:
        key = f"{name}_{size}_{color}"
        if key in self._cache:
            return self._cache[key]

        ss = size * 4  # 4x supersampling
        img = Image.new("RGBA", (ss, ss), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        c = color
        w = max(6, ss // 11)
        m = ss // 7

        if name == "back":
            pts = [(ss - m * 1.4, m), (m * 1.3, ss // 2), (ss - m * 1.4, ss - m)]
            d.polygon(pts, fill=c)
        elif name == "home":
            d.ellipse([m, m, ss - m, ss - m], outline=c, width=w)
            im = int(ss * 0.28)
            d.ellipse([im, im, ss - im, ss - im], fill=c)
        elif name == "recents":
            d.rounded_rectangle([m, m, ss - m, ss - m], radius=ss // 6, outline=c, width=w)
        elif name == "vol_up":
            d.polygon(
                [
                    (m, ss * 0.38),
                    (ss * 0.35, ss * 0.38),
                    (ss * 0.55, m * 1.2),
                    (ss * 0.55, ss - m * 1.2),
                    (ss * 0.35, ss * 0.62),
                    (m, ss * 0.62),
                ],
                fill=c,
            )
            d.arc([ss * 0.38, ss * 0.25, ss * 0.85, ss * 0.75], start=-50, end=50, fill=c, width=w)
        elif name == "vol_down":
            d.polygon(
                [
                    (m * 1.3, ss * 0.38),
                    (ss * 0.42, ss * 0.38),
                    (ss * 0.65, m * 1.2),
                    (ss * 0.65, ss - m * 1.2),
                    (ss * 0.42, ss * 0.62),
                    (m * 1.3, ss * 0.62),
                ],
                fill=c,
            )
        elif name == "mute":
            d.polygon(
                [
                    (m, ss * 0.38),
                    (ss * 0.32, ss * 0.38),
                    (ss * 0.52, m * 1.2),
                    (ss * 0.52, ss - m * 1.2),
                    (ss * 0.32, ss * 0.62),
                    (m, ss * 0.62),
                ],
                fill=c,
            )
            d.line([(ss * 0.64, ss * 0.34), (ss - m, ss * 0.66)], fill=c, width=w)
            d.line([(ss - m, ss * 0.34), (ss * 0.64, ss * 0.66)], fill=c, width=w)
        elif name == "power":
            d.arc([m, m * 1.2, ss - m, ss - m], start=-55, end=235, fill=c, width=w)
            d.line([(ss // 2, m * 0.7), (ss // 2, ss * 0.48)], fill=c, width=w)
        elif name == "camera":
            d.rounded_rectangle([m, ss * 0.26, ss - m, ss - m * 1.1], radius=ss // 8, outline=c, width=w)
            d.ellipse([ss * 0.33, ss * 0.38, ss * 0.67, ss * 0.72], outline=c, width=w)
        elif name == "bell":
            d.chord([m * 1.3, m, ss - m * 1.3, ss * 0.78], start=180, end=360, fill=c)
            d.rounded_rectangle([m, ss * 0.68, ss - m, ss * 0.78], radius=4, fill=c)
            d.ellipse([ss * 0.42, ss * 0.78, ss * 0.58, ss - m * 0.8], fill=c)
        elif name == "rotate":
            d.arc([m, m, ss - m, ss - m], start=15, end=285, fill=c, width=w)
            d.polygon([(ss - m * 0.7, ss * 0.45), (ss - m * 2.1, ss * 0.45), (ss - m * 1.4, ss * 0.22)], fill=c)
        elif name == "mirror":
            d.rounded_rectangle([ss * 0.24, m * 0.8, ss * 0.76, ss - m * 0.8], radius=ss // 8, outline=c, width=w)
            d.ellipse([ss * 0.45, ss - m * 1.8, ss * 0.55, ss - m * 1.1], fill=c)
        elif name == "dex":
            d.rounded_rectangle([m * 0.8, m, ss - m * 0.8, ss * 0.72], radius=ss // 10, outline=c, width=w)
            d.line([(ss // 2, ss * 0.72), (ss // 2, ss - m)], fill=c, width=w)
            d.line([(ss * 0.3, ss - m), (ss * 0.7, ss - m)], fill=c, width=w)
        elif name == "cpu":
            d.rounded_rectangle([m * 1.4, m * 1.4, ss - m * 1.4, ss - m * 1.4], radius=ss // 9, outline=c, width=w)
            d.rectangle([ss * 0.36, ss * 0.36, ss * 0.64, ss * 0.64], fill=c)
            for p in (0.32, 0.5, 0.68):
                px = int(ss * p)
                d.line([(px, m * 0.5), (px, m * 1.4)], fill=c, width=w // 2 + 2)
                d.line([(px, ss - m * 1.4), (px, ss - m * 0.5)], fill=c, width=w // 2 + 2)
                d.line([(m * 0.5, px), (m * 1.4, px)], fill=c, width=w // 2 + 2)
                d.line([(ss - m * 1.4, px), (ss - m * 0.5, px)], fill=c, width=w // 2 + 2)
        elif name == "apps":
            r = ss // 10
            boxes = [
                (m, m, ss * 0.45, ss * 0.45),
                (ss * 0.55, m, ss - m, ss * 0.45),
                (m, ss * 0.55, ss * 0.45, ss - m),
                (ss * 0.55, ss * 0.55, ss - m, ss - m),
            ]
            for b in boxes:
                d.rounded_rectangle(b, radius=r, fill=c)
        elif name == "info":
            d.ellipse([m, m, ss - m, ss - m], outline=c, width=w)
            d.ellipse([ss * 0.44, ss * 0.25, ss * 0.56, ss * 0.37], fill=c)
            d.line([(ss // 2, ss * 0.45), (ss // 2, ss * 0.74)], fill=c, width=w)
        elif name == "refresh":
            d.arc([m, m, ss - m, ss - m], start=35, end=315, fill=c, width=w)
            d.polygon([(ss - m * 0.8, ss * 0.22), (ss - m * 2.2, ss * 0.22), (ss - m * 1.2, ss * 0.42)], fill=c)
        elif name == "wifi":
            d.arc([m * 0.7, m * 1.2, ss - m * 0.7, ss], start=215, end=325, fill=c, width=w)
            d.arc([m * 1.6, m * 2.2, ss - m * 1.6, ss * 0.95], start=215, end=325, fill=c, width=w)
            d.ellipse([ss * 0.43, ss * 0.68, ss * 0.57, ss * 0.82], fill=c)
        elif name == "play":
            d.polygon([(ss * 0.25, m * 1.1), (ss - m * 1.1, ss // 2), (ss * 0.25, ss - m * 1.1)], fill=c)
        elif name == "stop":
            d.rounded_rectangle([m * 1.3, m * 1.3, ss - m * 1.3, ss - m * 1.3], radius=ss // 10, fill=c)
        elif name == "trash":
            d.line([(m * 1.2, ss * 0.24), (ss - m * 1.2, ss * 0.24)], fill=c, width=w)
            d.rounded_rectangle([ss * 0.24, ss * 0.24, ss * 0.76, ss - m], radius=ss // 12, outline=c, width=w)
        elif name == "download":
            d.line([(ss // 2, m), (ss // 2, ss * 0.65)], fill=c, width=w)
            d.polygon([(ss * 0.28, ss * 0.52), (ss * 0.72, ss * 0.52), (ss // 2, ss * 0.76)], fill=c)
            d.line([(m * 1.2, ss - m), (ss - m * 1.2, ss - m)], fill=c, width=w)
        else:
            d.ellipse([m, m, ss - m, ss - m], outline=c, width=w)

        final_img = img.resize((size, size), Image.Resampling.LANCZOS)
        ctk_img = ctk.CTkImage(light_image=final_img, dark_image=final_img, size=(size, size))
        self._cache[key] = ctk_img
        return ctk_img


class ScrcpyEmulatorSideBar(ctk.CTkToplevel):
    """
    Magnetic Android Studio Emulator Side-Toolbar that docks directly alongside the Scrcpy Mirror window!
    Automatically tracks the Scrcpy window position & height in real-time (30fps) as you drag or resize Scrcpy.
    """

    def __init__(
        self,
        parent: ctk.CTk,
        icons: ModernVectorIconFactory,
        target_title: str,
        proc: subprocess.Popen,
        on_action: Callable[[str], None],
    ) -> None:
        super().__init__(parent)
        self.icons = icons
        self.target_title = target_title
        self.proc = proc
        self.on_action = on_action
        self.alive = True
        self.bar_width = 58
        self.bar_height = 510

        # Borderless floating tool dock alongside the Scrcpy window
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(fg_color="#0d1118")
        self.geometry(f"{self.bar_width}x{self.bar_height}+100+100")

        # Drag support when user wants manual offset
        self._manual_drag_offset: Optional[Tuple[int, int]] = None
        self._drag_start_x = 0
        self._drag_start_y = 0

        self._build_toolbar()
        self.after(40, self._magnetic_dock_loop)

    def _build_toolbar(self) -> None:
        outer = ctk.CTkFrame(
            self,
            fg_color="#111622",
            corner_radius=12,
            border_width=1,
            border_color="#38bdf8",
        )
        outer.pack(fill="both", expand=True, padx=1, pady=1)

        # Top Grip Handle (Draggable)
        grip = ctk.CTkLabel(
            outer,
            text="⋮⋮",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color="#64748b",
            height=20,
            cursor="fleur",
        )
        grip.pack(fill="x", pady=(4, 2))
        grip.bind("<ButtonPress-1>", self._start_drag)
        grip.bind("<B1-Motion>", self._do_drag)
        grip.bind("<Double-Button-1>", self._snap_back)

        # Vertical stack of Android Emulator buttons (Power, Vol+, Vol-, Rotate, Screenshot, Notif, Back, Home, Recents)
        buttons = [
            # (Tooltip/Label, IconName, ActionCode, BgColor, HoverColor, IconRGBA, IsPrimaryNav)
            ("Power", "power", "26", "#be123c", "#9f1239", (255, 255, 255, 255), False),
            ("Vol +", "vol_up", "24", "#192130", "#263248", (226, 232, 240, 255), False),
            ("Vol -", "vol_down", "25", "#192130", "#263248", (226, 232, 240, 255), False),
            ("Mute", "mute", "164", "#192130", "#263248", (245, 158, 11, 255), False),
            ("Rotate", "rotate", "cmd_rotate", "#192130", "#263248", (56, 189, 248, 255), False),
            ("Snap", "camera", "cmd_screen", "#0d9488", "#0f766e", (255, 255, 255, 255), False),
            ("Alerts", "bell", "cmd_notif", "#192130", "#263248", (168, 85, 247, 255), False),
        ]

        for lbl_txt, ic_name, act, fg, hov, ic_col, _ in buttons:
            b = ctk.CTkButton(
                outer,
                text="",
                image=self.icons.get(ic_name, 20, ic_col),
                width=42,
                height=38,
                corner_radius=8,
                fg_color=fg,
                hover_color=hov,
                command=lambda a=act: self.on_action(a),
            )
            b.pack(padx=6, pady=3)

        # Divider separator before the Big 3 Android Navigation Buttons (Back, Home, Recents)
        sep = ctk.CTkFrame(outer, height=2, fg_color="#1e293b")
        sep.pack(fill="x", padx=8, pady=6)

        primary_nav = [
            ("BACK", "back", "4", "#1e293b", "#334155", (56, 189, 248, 255)),
            ("HOME", "home", "3", "#0284c7", "#0369a1", (255, 255, 255, 255)),
            ("RECENT", "recents", "187", "#1e293b", "#334155", (56, 189, 248, 255)),
        ]

        for lbl_txt, ic_name, act, fg, hov, ic_col in primary_nav:
            b = ctk.CTkButton(
                outer,
                text=lbl_txt,
                image=self.icons.get(ic_name, 22, ic_col),
                compound="top",
                width=46,
                height=52,
                corner_radius=10,
                fg_color=fg,
                hover_color=hov,
                font=ctk.CTkFont(size=8, weight="bold"),
                command=lambda a=act: self.on_action(a),
            )
            b.pack(padx=5, pady=4)

    def _start_drag(self, event: Any) -> None:
        self._drag_start_x = event.x_root - self.winfo_x()
        self._drag_start_y = event.y_root - self.winfo_y()

    def _do_drag(self, event: Any) -> None:
        nx = event.x_root - self._drag_start_x
        ny = event.y_root - self._drag_start_y
        self._manual_drag_offset = (nx, ny)
        self.geometry(f"{self.bar_width}x{self.bar_height}+{nx}+{ny}")

    def _snap_back(self, _event: Any) -> None:
        """Double-clicking the grip handle snaps the sidebar back to the right edge of Scrcpy."""
        self._manual_drag_offset = None

    def _magnetic_dock_loop(self) -> None:
        if not self.alive:
            return
        if self.proc.poll() is not None:
            self.close_bar()
            return

        rect = find_window_rect_by_title(self.target_title)
        if rect is not None:
            left, top, right, bottom, is_min = rect
            if is_min:
                self.withdraw()
            else:
                self.deiconify()
                if self._manual_drag_offset is None:
                    scr_w = self.winfo_screenwidth()
                    # Place flush on the right edge of Scrcpy window (or left edge if near right monitor border)
                    target_x = right + 2
                    if target_x + self.bar_width > scr_w:
                        target_x = max(0, left - self.bar_width - 2)
                    target_y = top + 32
                    cur_geom = f"{self.bar_width}x{self.bar_height}+{target_x}+{target_y}"
                    if self.geometry() != cur_geom:
                        self.geometry(cur_geom)

        self.after(35, self._magnetic_dock_loop)

    def close_bar(self) -> None:
        self.alive = False
        try:
            self.destroy()
        except Exception:
            pass


class BatchApkInstallModal(ctk.CTkToplevel):
    """
    Modern Animated Multi-APK Batch Installer Popup Modal with 60fps Dual Shimmer Progress Bar,
    Live Step Counter, Detailed APK Status Console, and Cancellation Support.
    """

    def __init__(
        self,
        parent: ctk.CTk,
        adb: "AdbController",
        serial: str,
        apk_paths: List[str],
        on_complete_cb: Callable[[], None],
    ) -> None:
        super().__init__(parent)
        self.adb = adb
        self.serial = serial
        self.apk_paths = apk_paths
        self.on_complete_cb = on_complete_cb
        self.total_count = len(apk_paths)
        self.current_idx = 0
        self.success_count = 0
        self.fail_count = 0
        self.cancelled = False
        self.finished = False

        # Smooth 60fps animation state
        self.phase = 0.0
        self.progress_target = 0.0
        self.progress_disp = 0.0

        self.title(f"Batch APK Installer — {self.total_count} Package(s) → {serial}")
        self.geometry("620x420")
        self.resizable(False, False)
        self.configure(fg_color="#0b0e14")
        self.transient(parent)
        self.grab_set()

        self._build_modal_ui()
        self.after(25, self._animate_progress_60fps)
        threading.Thread(target=self._batch_install_worker, daemon=True).start()

    def _build_modal_ui(self) -> None:
        header = ctk.CTkFrame(self, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b")
        header.pack(fill="x", padx=16, pady=(16, 10))

        self.lbl_title = ctk.CTkLabel(
            header,
            text=f"📦 Installing {self.total_count} APK Package(s) onto {self.serial}",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color="#38bdf8",
        )
        self.lbl_title.pack(anchor="w", padx=16, pady=(12, 2))

        self.lbl_current = ctk.CTkLabel(
            header,
            text="Preparing batch installation queue...",
            font=ctk.CTkFont(size=12),
            text_color="#cbd5e1",
        )
        self.lbl_current.pack(anchor="w", padx=16, pady=(0, 10))

        # 60fps Shimmer Progress Bar Canvas + Native ProgressBar
        prog_frame = ctk.CTkFrame(self, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b")
        prog_frame.pack(fill="x", padx=16, pady=6)

        top_p = ctk.CTkFrame(prog_frame, fg_color="transparent")
        top_p.pack(fill="x", padx=14, pady=(10, 4))

        self.lbl_step_counter = ctk.CTkLabel(
            top_p,
            text=f"Progress: 0 / {self.total_count} (0%)",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#38bdf8",
        )
        self.lbl_step_counter.pack(side="left")

        self.lbl_stats = ctk.CTkLabel(
            top_p,
            text="✅ 0 Success  |  ❌ 0 Failed",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#10b981",
        )
        self.lbl_stats.pack(side="right")

        self.prog_canvas = tk.Canvas(prog_frame, height=22, bg="#090c12", highlightthickness=0)
        self.prog_canvas.pack(fill="x", padx=14, pady=(2, 12))

        # Live Console Output Log
        self.log_box = ctk.CTkTextbox(
            self,
            height=165,
            fg_color="#080a0f",
            text_color="#e2e8f0",
            border_width=1,
            border_color="#1e293b",
            font=ctk.CTkFont(family="Consolas", size=11),
        )
        self.log_box.pack(fill="both", expand=True, padx=16, pady=6)

        # Action Button Footer
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(fill="x", padx=16, pady=(6, 14))

        self.action_btn = ctk.CTkButton(
            footer,
            text="⏹ Cancel Remaining",
            width=160,
            height=36,
            corner_radius=8,
            fg_color="#be123c",
            hover_color="#9f1239",
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._on_action_btn,
        )
        self.action_btn.pack(side="right")

    def _append_log(self, msg: str) -> None:
        ts = time.strftime("%H:%M:%S")
        self.log_box.insert("end", f"[{ts}] {msg}\n")
        self.log_box.see("end")

    def _animate_progress_60fps(self) -> None:
        if not self.winfo_exists():
            return
        self.phase += 0.16
        self.progress_disp += (self.progress_target - self.progress_disp) * 0.22

        self.prog_canvas.delete("all")
        w = max(self.prog_canvas.winfo_width(), 550)
        h = 22
        self.prog_canvas.create_rectangle(0, 0, w, h, fill="#090c12", outline="#1e293b")

        fill_w = int(w * max(0.0, min(1.0, self.progress_disp)))
        if fill_w > 2:
            bar_col = "#10b981" if (self.finished and self.fail_count == 0) else "#0284c7"
            if self.finished and self.fail_count > 0:
                bar_col = "#f59e0b"
            self.prog_canvas.create_rectangle(0, 0, fill_w, h, fill=bar_col, outline="")
            if not self.finished:
                shimmer_x = int((math.sin(self.phase) * 0.5 + 0.5) * max(10, fill_w - 50))
                self.prog_canvas.create_rectangle(
                    shimmer_x, 0, min(fill_w, shimmer_x + 50), h, fill="#38bdf8", outline=""
                )

        pct = int(round(self.progress_disp * 100))
        self.prog_canvas.create_text(w // 2, h // 2, text=f"{pct}%", fill="#ffffff", font=("Segoe UI", 9, "bold"))

        self.after(25, self._animate_progress_60fps)

    def _batch_install_worker(self) -> None:
        for idx, apk_path in enumerate(self.apk_paths, start=1):
            if self.cancelled:
                self.after(0, lambda: self._append_log("⚠️ Batch installation cancelled by user."))
                break

            fname = os.path.basename(apk_path)
            size_mb = os.path.getsize(apk_path) / (1024 * 1024) if os.path.isfile(apk_path) else 0.0
            base_prog = (idx - 1) / max(self.total_count, 1)
            mid_prog = (idx - 0.35) / max(self.total_count, 1)
            self.progress_target = mid_prog

            self.after(
                0,
                lambda i=idx, fn=fname, sz=size_mb, bp=base_prog: (
                    self.lbl_current.configure(text=f"Installing ({i}/{self.total_count}): {fn} ({sz:.1f} MB)..."),
                    self.lbl_step_counter.configure(
                        text=f"Progress: {i - 1} / {self.total_count} ({int(bp * 100)}%)"
                    ),
                    self._append_log(f"▶ [{i}/{self.total_count}] Installing {fn} ({sz:.1f} MB)..."),
                ),
            )

            t0 = time.time()
            code, out, err = self.adb.run_adb(["install", "-r", "-d", apk_path], serial=self.serial, timeout=180.0)
            elapsed = time.time() - t0

            if code == 0 and "Success" in out:
                self.success_count += 1
                self.after(
                    0,
                    lambda fn=fname, el=elapsed: self._append_log(f"  ✅ SUCCESS: {fn} installed in {el:.1f}s"),
                )
            else:
                self.fail_count += 1
                reason = (err or out or "Unknown ADB install error").replace("\n", " ")
                self.after(
                    0,
                    lambda fn=fname, r=reason: self._append_log(f"  ❌ FAILED: {fn} -> {r}"),
                )

            done_prog = idx / max(self.total_count, 1)
            self.progress_target = done_prog
            s_cnt, f_cnt = self.success_count, self.fail_count
            self.after(
                0,
                lambda i=idx, dp=done_prog, sc=s_cnt, fc=f_cnt: (
                    self.lbl_step_counter.configure(
                        text=f"Progress: {i} / {self.total_count} ({int(dp * 100)}%)"
                    ),
                    self.lbl_stats.configure(
                        text=f"✅ {sc} Success  |  ❌ {fc} Failed",
                        text_color="#10b981" if fc == 0 else "#f59e0b",
                    ),
                ),
            )

        self.finished = True
        self.progress_target = 1.0
        self.after(0, self._finalize_ui)

    def _finalize_ui(self) -> None:
        self.lbl_current.configure(
            text=f"Batch Complete: {self.success_count} installed, {self.fail_count} failed.",
            text_color="#10b981" if self.fail_count == 0 else "#f59e0b",
        )
        self.action_btn.configure(
            text="✅ Done / Close",
            fg_color="#10b981" if self.fail_count == 0 else "#0284c7",
            hover_color="#059669" if self.fail_count == 0 else "#0369a1",
        )
        try:
            self.on_complete_cb()
        except Exception:
            pass

    def _on_action_btn(self) -> None:
        if not self.finished:
            self.cancelled = True
            self.action_btn.configure(state="disabled", text="Cancelling...")
        else:
            self.grab_release()
            self.destroy()


class AdbController:
    """Thread-safe controller for executing hidden ADB and Scrcpy operations."""

    def __init__(self) -> None:
        self.adb_path = ADB_BIN
        self.scrcpy_path = SCRCPY_BIN

    def run_adb(self, args: List[str], serial: Optional[str] = None, timeout: float = 8.0) -> Tuple[int, str, str]:
        """Execute an ADB command silently with zero console popups."""
        cmd = [self.adb_path]
        if serial:
            cmd.extend(["-s", serial])
        cmd.extend(args)
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                **get_subprocess_kwargs(),
            )
            return proc.returncode, proc.stdout.strip(), proc.stderr.strip()
        except subprocess.TimeoutExpired:
            return -1, "", "Command timed out"
        except Exception as exc:
            return -1, "", str(exc)

    def list_devices(self) -> List[Dict[str, str]]:
        code, out, _ = self.run_adb(["devices", "-l"], timeout=5.0)
        devices: List[Dict[str, str]] = []
        if code != 0 or not out:
            return devices
        for line in out.splitlines()[1:]:
            line = line.strip()
            if not line or line.startswith("*"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                serial = parts[0]
                state = parts[1]
                meta = {}
                for token in parts[2:]:
                    if ":" in token:
                        k, v = token.split(":", 1)
                        meta[k] = v
                devices.append(
                    {
                        "serial": serial,
                        "state": state,
                        "model": meta.get("model", "Unknown"),
                        "device": meta.get("device", "Unknown"),
                        "transport_id": meta.get("transport_id", ""),
                    }
                )
        return devices

    def send_keyevent(self, serial: str, keycode: str) -> bool:
        code, _, _ = self.run_adb(["shell", "input", "keyevent", str(keycode)], serial=serial, timeout=3.0)
        return code == 0

    def get_device_info(self, serial: str) -> Dict[str, str]:
        script = (
            "echo '===PROPS==='; "
            "getprop ro.product.manufacturer; "
            "getprop ro.product.model; "
            "getprop ro.product.device; "
            "getprop ro.build.version.release; "
            "getprop ro.build.version.sdk; "
            "getprop ro.build.display.id; "
            "getprop ro.build.version.security_patch; "
            "getprop ro.product.cpu.abi; "
            "getprop ro.soc.manufacturer; "
            "getprop ro.soc.model; "
            "getprop gsm.version.baseband; "
            "uname -r; "
            "uptime -p 2>/dev/null || uptime; "
            "echo '===WM==='; wm size; wm density; "
            "echo '===BAT==='; dumpsys battery; "
            "echo '===MEM==='; cat /proc/meminfo | head -n 6; "
            "echo '===DF==='; df -h /data 2>/dev/null | tail -n 1; "
            "echo '===IP==='; ip -4 addr show wlan0 2>/dev/null | grep inet"
        )
        code, out, err = self.run_adb(["shell", script], serial=serial, timeout=8.0)
        info: Dict[str, str] = {"Serial": serial}
        if code != 0:
            info["Error"] = err or "Failed to query device"
            return info

        sections = re.split(r"===(PROPS|WM|BAT|MEM|DF|IP)===", out)
        sec_map: Dict[str, str] = {}
        for i in range(1, len(sections) - 1, 2):
            sec_map[sections[i]] = sections[i + 1].strip()

        props = [line.strip() for line in sec_map.get("PROPS", "").splitlines()]
        prop_keys = [
            "Manufacturer",
            "Model",
            "Codename",
            "Android Version",
            "SDK Level",
            "Build ID",
            "Security Patch",
            "CPU ABI",
            "SoC Vendor",
            "SoC Model",
            "Baseband",
            "Kernel Version",
            "System Uptime",
        ]
        for idx, k in enumerate(prop_keys):
            info[k] = props[idx] if idx < len(props) and props[idx] else "N/A"

        wm_raw = sec_map.get("WM", "")
        res_match = re.search(r"Physical size:\s*(\S+)", wm_raw)
        den_match = re.search(r"Physical density:\s*(\S+)", wm_raw)
        info["Display Resolution"] = res_match.group(1) if res_match else "N/A"
        info["Display Density"] = f"{den_match.group(1)} dpi" if den_match else "N/A"

        bat_raw = sec_map.get("BAT", "")
        lvl_m = re.search(r"level:\s*(\d+)", bat_raw)
        temp_m = re.search(r"temperature:\s*(\d+)", bat_raw)
        volt_m = re.search(r"voltage:\s*(\d+)", bat_raw)
        tech_m = re.search(r"technology:\s*(\S+)", bat_raw)
        info["Battery Level"] = f"{lvl_m.group(1)}%" if lvl_m else "N/A"
        info["Battery Temp"] = f"{int(temp_m.group(1)) / 10.0:.1f} °C" if temp_m else "N/A"
        info["Battery Voltage"] = f"{volt_m.group(1)} mV" if volt_m else "N/A"
        info["Battery Tech"] = tech_m.group(1) if tech_m else "Li-ion"

        mem_raw = sec_map.get("MEM", "")
        mt_m = re.search(r"MemTotal:\s*(\d+)", mem_raw)
        ma_m = re.search(r"MemAvailable:\s*(\d+)", mem_raw)
        if mt_m and ma_m:
            total_mb = int(mt_m.group(1)) // 1024
            avail_mb = int(ma_m.group(1)) // 1024
            used_mb = total_mb - avail_mb
            info["System RAM"] = f"{used_mb} MB / {total_mb} MB ({avail_mb} MB Free)"
        else:
            info["System RAM"] = "N/A"

        df_raw = sec_map.get("DF", "")
        df_parts = df_raw.split()
        if len(df_parts) >= 5:
            info["Internal Storage (/data)"] = f"{df_parts[2]} used / {df_parts[1]} total ({df_parts[4]})"
        else:
            info["Internal Storage (/data)"] = "N/A"

        ip_raw = sec_map.get("IP", "")
        ip_m = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)", ip_raw)
        info["Wi-Fi LAN IP (wlan0)"] = ip_m.group(1) if ip_m else "Disconnected / N/A"

        return info


class SystemMonitorEngine:
    """Thread-safe live system monitor & task manager engine for connected Android devices."""

    def __init__(self, adb: AdbController) -> None:
        self.adb = adb
        self.lock = threading.Lock()
        self.running = True
        self.active_serial: Optional[str] = None
        self.paused = False

        self.cpu_total_pct: float = 0.0
        self.ram_used_mb: float = 0.0
        self.ram_total_mb: float = 12288.0
        self.ram_pct: float = 0.0
        self.swap_used_mb: float = 0.0
        self.swap_total_mb: float = 1.0
        self.battery_level: int = 0
        self.battery_temp_c: float = 0.0
        self.tasks_total: int = 0
        self.tasks_running: int = 0

        self.history_cpu = deque([0.0] * 60, maxlen=60)
        self.history_ram = deque([0.0] * 60, maxlen=60)
        self.history_temp = deque([0.0] * 60, maxlen=60)

        self.processes: List[Dict[str, Any]] = []

    def poll_once(self) -> None:
        serial = self.active_serial
        if not serial or self.paused:
            return

        cmd_str = "top -b -n 1 -m 45; echo '===BAT==='; dumpsys battery | grep -E 'level:|temperature:'"
        code, out, _ = self.adb.run_adb(["shell", cmd_str], serial=serial, timeout=5.0)
        if code != 0 or not out:
            return

        parts = out.split("===BAT===")
        top_raw = parts[0]
        bat_raw = parts[1] if len(parts) > 1 else ""

        tasks_tot, tasks_run = 0, 0
        mem_tot, mem_used = 1.0, 0.0
        swap_tot, swap_used = 1.0, 0.0
        cpu_pct = 0.0
        proc_list: List[Dict[str, Any]] = []

        lines = top_raw.splitlines()
        in_table = False

        for line in lines:
            s = line.strip()
            if not s:
                continue
            if s.startswith("Tasks:"):
                m_t = re.search(r"(\d+)\s+total,\s+(\d+)\s+running", s)
                if m_t:
                    tasks_tot = int(m_t.group(1))
                    tasks_run = int(m_t.group(2))
            elif s.startswith("Mem:"):
                m_m = re.search(r"(\d+)([KMG]?)\s+total,\s+(\d+)([KMG]?)\s+used", s)
                if m_m:
                    mem_tot = self._to_mb(int(m_m.group(1)), m_m.group(2))
                    mem_used = self._to_mb(int(m_m.group(3)), m_m.group(4))
            elif s.startswith("Swap:"):
                m_s = re.search(r"(\d+)([KMG]?)\s+total,\s+(\d+)([KMG]?)\s+used", s)
                if m_s:
                    swap_tot = self._to_mb(int(m_s.group(1)), m_s.group(2))
                    swap_used = self._to_mb(int(m_s.group(3)), m_s.group(4))
            elif "%cpu" in s and "%idle" in s:
                m_c = re.search(r"(\d+)%cpu.*?(\d+)%idle", s)
                if m_c:
                    total_cap = max(float(m_c.group(1)), 100.0)
                    idle_cap = float(m_c.group(2))
                    cpu_pct = max(0.0, min(100.0, ((total_cap - idle_cap) / total_cap) * 100.0))
            elif s.startswith("PID ") and "ARGS" in s:
                in_table = True
            elif in_table:
                tokens = s.split(None, 11)
                if len(tokens) >= 12 and tokens[0].isdigit():
                    pid = int(tokens[0])
                    user = tokens[1]
                    res_str = tokens[5]
                    state = tokens[7]
                    try:
                        p_cpu = float(tokens[8])
                    except ValueError:
                        p_cpu = 0.0
                    try:
                        p_mem = float(tokens[9])
                    except ValueError:
                        p_mem = 0.0
                    time_str = tokens[10]
                    args_str = tokens[11].strip()
                    if args_str.startswith("top -b"):
                        continue
                    proc_list.append(
                        {
                            "pid": pid,
                            "user": user,
                            "res": res_str,
                            "state": state,
                            "cpu": p_cpu,
                            "mem": p_mem,
                            "time": time_str,
                            "name": args_str,
                        }
                    )

        bat_lvl = 0
        bat_temp = 0.0
        m_bl = re.search(r"level:\s*(\d+)", bat_raw)
        m_bt = re.search(r"temperature:\s*(\d+)", bat_raw)
        if m_bl:
            bat_lvl = int(m_bl.group(1))
        if m_bt:
            bat_temp = int(m_bt.group(1)) / 10.0

        ram_percentage = (mem_used / max(mem_tot, 1.0)) * 100.0

        with self.lock:
            self.tasks_total = tasks_tot
            self.tasks_running = tasks_run
            self.ram_total_mb = mem_tot
            self.ram_used_mb = mem_used
            self.ram_pct = ram_percentage
            self.swap_total_mb = swap_tot
            self.swap_used_mb = swap_used
            self.cpu_total_pct = cpu_pct
            self.battery_level = bat_lvl
            self.battery_temp_c = bat_temp
            self.processes = proc_list

            self.history_cpu.append(cpu_pct)
            self.history_ram.append(ram_percentage)
            self.history_temp.append(bat_temp)

    @staticmethod
    def _to_mb(val: int, unit: str) -> float:
        u = unit.upper()
        if u == "G":
            return val * 1024.0
        if u == "K":
            return val / 1024.0
        return float(val)

    def background_loop(self) -> None:
        while self.running:
            self.poll_once()
            time.sleep(2.0)


class AdbScrcpyStudioApp(ctk.CTk):
    """Modern Animated Cross-Platform GUI Workstation for ADB, Task Manager, Scrcpy & PC DeX Mode."""

    def __init__(self) -> None:
        super().__init__()

        self.title(f"J.A.R.V.I.S. Android & Scrcpy DeX Studio — v{APP_VERSION}")
        self.geometry("1280x810")
        self.minsize(1120, 720)
        self.configure(fg_color="#090b10")

        ico_candidate = os.path.join(get_bundle_dir(), "assets", "android_scrcpy_dex.ico")
        if os.name == "nt" and os.path.isfile(ico_candidate):
            try:
                self.iconbitmap(ico_candidate)
            except Exception:
                pass

        self.icons = ModernVectorIconFactory()
        self.adb = AdbController()
        self.monitor = SystemMonitorEngine(self.adb)
        self.current_serial: Optional[str] = None
        self.devices_cache: List[Dict[str, str]] = []
        self.packages_cache: List[str] = []

        # Managed child processes & magnetic emulator side-toolbar
        self.scrcpy_mirror_proc: Optional[subprocess.Popen] = None
        self.scrcpy_dex_proc: Optional[subprocess.Popen] = None
        self.emulator_sidebar: Optional[ScrcpyEmulatorSideBar] = None
        self.parent_pid = os.getpid()
        self._rotation_state = 0

        # Smooth Animation State (60fps Lerp Engine)
        self.anim_phase: float = 0.0
        self.disp_cpu: float = 0.0
        self.target_cpu: float = 0.0
        self.disp_ram: float = 0.0
        self.target_ram: float = 0.0
        self.disp_temp: float = 0.0
        self.target_temp: float = 0.0
        self.nav_glow_x: float = 0.0
        self.nav_target_x: float = 0.0

        self._configure_treeview_style()
        self._build_top_bar()
        self._build_animated_view_switcher()
        self._build_views()
        self._build_status_footer()

        # Start telemetry daemon thread
        self.monitor_thread = threading.Thread(target=self.monitor.background_loop, daemon=True)
        self.monitor_thread.start()

        # Start parent-coupled lifecycle watchdog (Rule #6)
        self.watchdog_thread = threading.Thread(target=self._lifecycle_watchdog_loop, daemon=True)
        self.watchdog_thread.start()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Initial device discovery & 60fps animation loop
        self.refresh_devices()
        self.after(25, self._animation_tick_60fps)
        self.after(1500, self._periodic_table_sync)

    def _configure_treeview_style(self) -> None:
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Studio.Treeview",
            background="#10141d",
            foreground="#e2e8f0",
            fieldbackground="#10141d",
            rowheight=30,
            borderwidth=0,
            font=("Segoe UI", 10),
        )
        style.configure(
            "Studio.Treeview.Heading",
            background="#1a2130",
            foreground="#38bdf8",
            font=("Segoe UI", 10, "bold"),
            borderwidth=0,
            relief="flat",
        )
        style.map(
            "Studio.Treeview",
            background=[("selected", "#0284c7")],
            foreground=[("selected", "#ffffff")],
        )

    # =========================================================================
    # TOP HEADER BAR WITH PULSING TELEMETRY LED & MODERN VECTOR ICONS
    # =========================================================================
    def _build_top_bar(self) -> None:
        self.top_bar = ctk.CTkFrame(
            self,
            fg_color="#111621",
            corner_radius=12,
            border_width=1,
            border_color="#1e293b",
            height=62,
        )
        self.top_bar.pack(fill="x", padx=14, pady=(12, 6))

        self.led_canvas = tk.Canvas(self.top_bar, width=26, height=26, bg="#111621", highlightthickness=0)
        self.led_canvas.pack(side="left", padx=(14, 6), pady=12)

        self.brand_label = ctk.CTkLabel(
            self.top_bar,
            text="J.A.R.V.I.S. ANDROID & SCRCPY DEX STUDIO",
            font=ctk.CTkFont(family="Segoe UI", size=16, weight="bold"),
            text_color="#38bdf8",
        )
        self.brand_label.pack(side="left", padx=(2, 18), pady=12)

        self.device_combo = ctk.CTkOptionMenu(
            self.top_bar,
            values=["Scanning..."],
            command=self._on_device_selected,
            width=265,
            height=34,
            fg_color="#192130",
            button_color="#0284c7",
            button_hover_color="#0369a1",
            font=ctk.CTkFont(size=12, weight="bold"),
        )
        self.device_combo.pack(side="left", padx=6)

        self.refresh_dev_btn = ctk.CTkButton(
            self.top_bar,
            text="Scan Devices",
            image=self.icons.get("refresh", 18, (56, 189, 248, 255)),
            width=130,
            height=34,
            fg_color="#192130",
            hover_color="#263248",
            border_width=1,
            border_color="#334155",
            command=self.refresh_devices,
        )
        self.refresh_dev_btn.pack(side="left", padx=6)

        self.wireless_entry = ctk.CTkEntry(
            self.top_bar,
            placeholder_text="Wi-Fi IP:Port (192.168.8.246:5555)",
            width=225,
            height=34,
            fg_color="#0b0e14",
            border_color="#334155",
        )
        self.wireless_entry.pack(side="left", padx=(14, 6))

        self.connect_ip_btn = ctk.CTkButton(
            self.top_bar,
            text="Wi-Fi Pair",
            image=self.icons.get("wifi", 18, (255, 255, 255, 255)),
            width=115,
            height=34,
            fg_color="#0d9488",
            hover_color="#0f766e",
            command=self._connect_wireless_adb,
        )
        self.connect_ip_btn.pack(side="left", padx=4)

        self.tcpip_btn = ctk.CTkButton(
            self.top_bar,
            text=":5555",
            width=68,
            height=34,
            fg_color="#1e293b",
            hover_color="#334155",
            command=self._enable_tcpip_5555,
        )
        self.tcpip_btn.pack(side="left", padx=4)

    # =========================================================================
    # SMOOTH ANIMATED NAVIGATION SWITCHER BAR
    # =========================================================================
    def _build_animated_view_switcher(self) -> None:
        self.switcher_card = ctk.CTkFrame(
            self,
            fg_color="#111621",
            corner_radius=12,
            border_width=1,
            border_color="#1e293b",
        )
        self.switcher_card.pack(fill="x", padx=14, pady=(0, 6))

        btn_row = ctk.CTkFrame(self.switcher_card, fg_color="transparent")
        btn_row.pack(fill="x", padx=10, pady=(6, 2))
        btn_row.grid_columnconfigure((0, 1, 2, 3, 4), weight=1)

        self.tab_buttons: List[ctk.CTkButton] = []
        tab_defs = [
            ("Scrcpy Mirror & Controls", "mirror", 0),
            ("PC DeX / Desktop Mode", "dex", 1),
            ("Live System Task Manager", "cpu", 2),
            ("App Manager (APK)", "apps", 3),
            ("Device Hardware Info", "info", 4),
        ]

        for label, ic, idx in tab_defs:
            b = ctk.CTkButton(
                btn_row,
                text=label,
                image=self.icons.get(ic, 20, (56, 189, 248, 255)),
                height=36,
                corner_radius=8,
                fg_color="#0284c7" if idx == 0 else "transparent",
                hover_color="#1e293b",
                font=ctk.CTkFont(size=13, weight="bold"),
                command=lambda i=idx: self._switch_view(i),
            )
            b.grid(row=0, column=idx, sticky="ew", padx=4)
            self.tab_buttons.append(b)

        self.indicator_canvas = tk.Canvas(self.switcher_card, height=4, bg="#111621", highlightthickness=0)
        self.indicator_canvas.pack(fill="x", padx=14, pady=(0, 4))

    def _build_views(self) -> None:
        self.view_host = ctk.CTkFrame(
            self,
            fg_color="#0d1119",
            corner_radius=12,
            border_width=1,
            border_color="#1e293b",
        )
        self.view_host.pack(fill="both", expand=True, padx=14, pady=(0, 6))

        self.views: List[ctk.CTkFrame] = []
        for _ in range(5):
            f = ctk.CTkFrame(self.view_host, fg_color="transparent")
            self.views.append(f)

        self.tab_mirror = self.views[0]
        self.tab_dex = self.views[1]
        self.tab_monitor = self.views[2]
        self.tab_apps = self.views[3]
        self.tab_info = self.views[4]

        self._init_tab_scrcpy_mirror()
        self._init_tab_dex_desktop()
        self._init_tab_system_monitor()
        self._init_tab_app_manager()
        self._init_tab_device_info()

        self.active_view_idx = 0
        self.views[0].pack(fill="both", expand=True, padx=6, pady=6)

    def _switch_view(self, index: int) -> None:
        if index == self.active_view_idx:
            return
        self.views[self.active_view_idx].pack_forget()
        self.active_view_idx = index
        self.views[index].pack(fill="both", expand=True, padx=6, pady=6)

        for idx, btn in enumerate(self.tab_buttons):
            if idx == index:
                btn.configure(fg_color="#0284c7", text_color="#ffffff")
            else:
                btn.configure(fg_color="transparent", text_color="#cbd5e1")

        w = max(self.indicator_canvas.winfo_width(), 1000)
        seg_w = w / 5.0
        self.nav_target_x = index * seg_w

    # =========================================================================
    # 60FPS SMOOTH ANIMATION & VECTOR GAUGE RENDERER
    # =========================================================================
    def _animation_tick_60fps(self) -> None:
        self.anim_phase += 0.12

        self.led_canvas.delete("all")
        pulse = (math.sin(self.anim_phase) + 1.0) * 0.5
        base_col = "#10b981" if self.current_serial else "#f43f5e"
        halo_col = "#064e3b" if self.current_serial else "#4c0519"
        r_outer = 7 + pulse * 4
        self.led_canvas.create_oval(13 - r_outer, 13 - r_outer, 13 + r_outer, 13 + r_outer, fill=halo_col, outline="")
        self.led_canvas.create_oval(8, 8, 18, 18, fill=base_col, outline="#ffffff", width=1)

        w = max(self.indicator_canvas.winfo_width(), 1000)
        seg_w = w / 5.0
        self.nav_target_x = self.active_view_idx * seg_w
        self.nav_glow_x += (self.nav_target_x - self.nav_glow_x) * 0.25
        self.indicator_canvas.delete("all")
        self.indicator_canvas.create_rectangle(
            self.nav_glow_x + 12,
            0,
            self.nav_glow_x + seg_w - 12,
            4,
            fill="#38bdf8",
            outline="",
        )

        with self.monitor.lock:
            self.target_cpu = self.monitor.cpu_total_pct
            self.target_ram = self.monitor.ram_pct
            self.target_temp = self.monitor.battery_temp_c

        self.disp_cpu += (self.target_cpu - self.disp_cpu) * 0.18
        self.disp_ram += (self.target_ram - self.disp_ram) * 0.18
        self.disp_temp += (self.target_temp - self.disp_temp) * 0.18

        if self.active_view_idx == 2:
            self._draw_radial_gauge(self.gauge_cpu, self.disp_cpu, 100.0, "#38bdf8", f"{self.disp_cpu:.1f}%", "CPU")
            self._draw_radial_gauge(self.gauge_ram, self.disp_ram, 100.0, "#a855f7", f"{self.disp_ram:.1f}%", "RAM")
            self._draw_radial_gauge(self.gauge_temp, self.disp_temp, 60.0, "#10b981", f"{self.disp_temp:.1f}°C", "TEMP")

        self.after(25, self._animation_tick_60fps)

    def _draw_radial_gauge(
        self, canvas: tk.Canvas, val: float, max_v: float, color: str, text_main: str, text_sub: str
    ) -> None:
        canvas.delete("all")
        cx, cy, r = 38, 38, 29
        canvas.create_arc(cx - r, cy - r, cx + r, cy + r, start=225, extent=-270, style="arc", outline="#1e293b", width=7)
        norm = max(0.0, min(1.0, val / max(max_v, 1.0)))
        ext = -270.0 * norm
        canvas.create_arc(cx - r, cy - r, cx + r, cy + r, start=225, extent=ext, style="arc", outline=color, width=7)
        canvas.create_text(cx, cy - 4, text=text_main, fill="#f8fafc", font=("Segoe UI", 9, "bold"))
        canvas.create_text(cx, cy + 11, text=text_sub, fill="#64748b", font=("Segoe UI", 7, "bold"))

    # -------------------------------------------------------------------------
    # TAB 1: SCRCPY MIRROR & MAGNETIC SIDE-TOOLBAR CONFIGURATION
    # -------------------------------------------------------------------------
    def _init_tab_scrcpy_mirror(self) -> None:
        container = ctk.CTkFrame(self.tab_mirror, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=6, pady=4)

        left_panel = ctk.CTkFrame(
            container, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b"
        )
        left_panel.pack(side="left", fill="both", expand=True, padx=(0, 8), pady=4)

        title = ctk.CTkLabel(
            left_panel,
            text="  Scrcpy 4.0 Hardware Video & Audio Stream Studio",
            image=self.icons.get("mirror", 22, (56, 189, 248, 255)),
            compound="left",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color="#38bdf8",
        )
        title.pack(anchor="w", padx=18, pady=(16, 12))

        grid = ctk.CTkFrame(left_panel, fg_color="transparent")
        grid.pack(fill="x", padx=18, pady=4)
        grid.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(grid, text="Max Resolution:", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=0, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.mirror_res_var = ctk.StringVar(value="1080 (FHD)")
        ctk.CTkOptionMenu(
            grid,
            variable=self.mirror_res_var,
            values=["Native (Uncapped)", "2560 (QHD+)", "1920 (FHD+)", "1600 (HD+)", "1280 (720p)", "1080 (FHD)", "800 (Low Latency)"],
            fg_color="#1e293b",
        ).grid(row=0, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(grid, text="Video Bitrate:", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=1, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.mirror_vbit_var = ctk.StringVar(value="12M")
        ctk.CTkOptionMenu(
            grid,
            variable=self.mirror_vbit_var,
            values=["2M", "4M", "8M", "12M", "16M", "24M", "35M", "50M (Ultra HQ)"],
            fg_color="#1e293b",
        ).grid(row=1, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(grid, text="Target Frame Rate (FPS):", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=2, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.mirror_fps_var = ctk.StringVar(value="60")
        ctk.CTkOptionMenu(
            grid,
            variable=self.mirror_fps_var,
            values=["30", "60", "90", "120", "144", "240"],
            fg_color="#1e293b",
        ).grid(row=2, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(grid, text="Video Hardware Codec:", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=3, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.mirror_vcodec_var = ctk.StringVar(value="h264")
        ctk.CTkOptionMenu(
            grid,
            variable=self.mirror_vcodec_var,
            values=["h264", "h265", "av1"],
            fg_color="#1e293b",
        ).grid(row=3, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(grid, text="Audio Bitrate:", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=4, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.mirror_abit_var = ctk.StringVar(value="128K")
        ctk.CTkOptionMenu(
            grid,
            variable=self.mirror_abit_var,
            values=["64K", "96K", "128K", "192K", "256K", "320K (Studio)"],
            fg_color="#1e293b",
        ).grid(row=4, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(grid, text="Audio Codec:", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=5, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.mirror_acodec_var = ctk.StringVar(value="opus")
        ctk.CTkOptionMenu(
            grid,
            variable=self.mirror_acodec_var,
            values=["opus", "aac", "flac", "raw"],
            fg_color="#1e293b",
        ).grid(row=5, column=1, sticky="ew", pady=7)

        toggles_frame = ctk.CTkFrame(left_panel, fg_color="#0e131d", corner_radius=10)
        toggles_frame.pack(fill="x", padx=18, pady=10)

        self.mirror_attach_sidebar = ctk.CTkCheckBox(
            toggles_frame,
            text="Attach Magnetic Android Emulator Navigation Side-Toolbar Alongside Mirrored Display",
            text_color="#38bdf8",
            font=ctk.CTkFont(size=12, weight="bold"),
        )
        self.mirror_attach_sidebar.select()
        self.mirror_attach_sidebar.pack(anchor="w", padx=14, pady=(10, 5))

        self.mirror_turn_screen_off = ctk.CTkCheckBox(toggles_frame, text="Turn Physical Phone Screen Off While Mirroring (-S)")
        self.mirror_turn_screen_off.pack(anchor="w", padx=14, pady=5)

        self.mirror_stay_awake = ctk.CTkCheckBox(toggles_frame, text="Keep Device Awake While Plugged In (-w)")
        self.mirror_stay_awake.select()
        self.mirror_stay_awake.pack(anchor="w", padx=14, pady=5)

        self.mirror_always_top = ctk.CTkCheckBox(toggles_frame, text="Always on Top Window (--always-on-top)")
        self.mirror_always_top.pack(anchor="w", padx=14, pady=5)

        self.mirror_no_audio = ctk.CTkCheckBox(toggles_frame, text="Mute / Disable Audio Forwarding (--no-audio)")
        self.mirror_no_audio.pack(anchor="w", padx=14, pady=5)

        self.mirror_show_touches = ctk.CTkCheckBox(toggles_frame, text="Show Physical Finger Touches (-t)")
        self.mirror_show_touches.pack(anchor="w", padx=14, pady=(5, 10))

        btn_row = ctk.CTkFrame(left_panel, fg_color="transparent")
        btn_row.pack(fill="x", padx=18, pady=(6, 14))

        self.launch_mirror_btn = ctk.CTkButton(
            btn_row,
            text="  LAUNCH SCRCPY MIRROR + SIDE-TOOLBAR",
            image=self.icons.get("play", 20, (255, 255, 255, 255)),
            height=44,
            corner_radius=10,
            fg_color="#0284c7",
            hover_color="#0369a1",
            font=ctk.CTkFont(size=14, weight="bold"),
            command=self.start_scrcpy_mirror,
        )
        self.launch_mirror_btn.pack(side="left", fill="x", expand=True, padx=(0, 8))

        self.stop_mirror_btn = ctk.CTkButton(
            btn_row,
            text="  STOP MIRROR",
            image=self.icons.get("stop", 18, (255, 255, 255, 255)),
            height=44,
            width=160,
            corner_radius=10,
            fg_color="#be123c",
            hover_color="#9f1239",
            font=ctk.CTkFont(size=13, weight="bold"),
            command=self.stop_scrcpy_mirror,
        )
        self.stop_mirror_btn.pack(side="left")

        # Right column: Side-Toolbar Preview & Text Injection
        right_panel = ctk.CTkFrame(
            container, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b", width=360
        )
        right_panel.pack(side="right", fill="y", padx=(8, 0), pady=4)
        right_panel.pack_propagate(False)

        ctk.CTkLabel(
            right_panel,
            text="Magnetic Emulator Side-Toolbar",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color="#38bdf8",
        ).pack(anchor="w", padx=18, pady=(16, 4))

        side_info = (
            "When you launch Scrcpy Mirror, a sleek vertical\n"
            "Android Studio Emulator Side-Toolbar docks right\n"
            "alongside the mirrored phone display window:\n\n"
            "• ⏻ Power / Lock Screen\n"
            "• 🔊 Volume Up / 🔉 Volume Down / 🔇 Mute\n"
            "• 🔄 Rotate Screen Orientation\n"
            "• 📸 Instant PNG Screenshot Capture\n"
            "• 🔔 Pull Down Notifications Shade\n"
            "• ◀ BACK  |  ● HOME  |  ■ RECENTS\n\n"
            "The toolbar automatically follows the Scrcpy window\n"
            "as you move, resize, or minimize it!"
        )
        ctk.CTkLabel(
            right_panel,
            text=side_info,
            font=ctk.CTkFont(size=12),
            text_color="#cbd5e1",
            justify="left",
        ).pack(anchor="w", padx=18, pady=8)

        txt_box = ctk.CTkFrame(right_panel, fg_color="#0d111a", corner_radius=10, border_width=1, border_color="#1e293b")
        txt_box.pack(fill="x", padx=18, pady=(12, 6))

        ctk.CTkLabel(
            txt_box,
            text="DIRECT KEYBOARD TEXT INJECTION",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color="#64748b",
        ).pack(pady=(8, 4))

        self.inject_text_entry = ctk.CTkEntry(
            txt_box,
            placeholder_text="Type text to inject directly to phone...",
            fg_color="#131926",
        )
        self.inject_text_entry.pack(fill="x", padx=10, pady=4)

        ctk.CTkButton(
            txt_box,
            text="Send Text to Device",
            height=32,
            fg_color="#0d9488",
            hover_color="#0f766e",
            command=self._send_text_to_device,
        ).pack(fill="x", padx=10, pady=(4, 10))

    # -------------------------------------------------------------------------
    # TAB 2: PC DEX / DESKTOP WORKSTATION MODE
    # -------------------------------------------------------------------------
    def _init_tab_dex_desktop(self) -> None:
        container = ctk.CTkFrame(self.tab_dex, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=6, pady=4)

        left_card = ctk.CTkFrame(
            container, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b"
        )
        left_card.pack(side="left", fill="both", expand=True, padx=(0, 8), pady=4)

        ctk.CTkLabel(
            left_card,
            text="  PC as Samsung DeX / Android Desktop Mode Workstation",
            image=self.icons.get("dex", 22, (56, 189, 248, 255)),
            compound="left",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color="#38bdf8",
        ).pack(anchor="w", padx=18, pady=(16, 6))

        desc = (
            "Spawns an independent Virtual External Display via Scrcpy 4.0 (--new-display) and activates\n"
            "Android Freeform Multi-Window & Desktop External Display flags. Your phone screen stays\n"
            "completely independent while your PC acts as a full Desktop monitor with mouse & keyboard."
        )
        ctk.CTkLabel(
            left_card,
            text=desc,
            font=ctk.CTkFont(size=12),
            text_color="#94a3b8",
            justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 12))

        form = ctk.CTkFrame(left_card, fg_color="transparent")
        form.pack(fill="x", padx=18, pady=4)
        form.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(form, text="Desktop Display Resolution:", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=0, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.dex_res_var = ctk.StringVar(value="1920x1080")
        ctk.CTkOptionMenu(
            form,
            variable=self.dex_res_var,
            values=["1920x1080", "2560x1440", "3840x2160", "1600x900", "1366x768", "2560x1080 (Ultrawide)"],
            fg_color="#1e293b",
        ).grid(row=0, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(form, text="Desktop UI Density (DPI):", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=1, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.dex_dpi_var = ctk.StringVar(value="160 (Desktop Native)")
        ctk.CTkOptionMenu(
            form,
            variable=self.dex_dpi_var,
            values=[
                "120 (Ultra Compact Desktop)",
                "140 (Compact Desktop)",
                "160 (Desktop Native)",
                "200 (Balanced Desktop)",
                "240 (Large Desktop / Tablet)",
                "320 (High DPI)",
            ],
            fg_color="#1e293b",
        ).grid(row=1, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(form, text="Desktop Refresh Rate (FPS):", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=2, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.dex_fps_var = ctk.StringVar(value="60")
        ctk.CTkOptionMenu(
            form,
            variable=self.dex_fps_var,
            values=["60", "90", "120", "144", "240"],
            fg_color="#1e293b",
        ).grid(row=2, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(form, text="Desktop Video Bitrate:", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=3, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.dex_vbit_var = ctk.StringVar(value="20M")
        ctk.CTkOptionMenu(
            form,
            variable=self.dex_vbit_var,
            values=["12M", "16M", "20M", "30M", "45M", "60M"],
            fg_color="#1e293b",
        ).grid(row=3, column=1, sticky="ew", pady=7)

        ctk.CTkLabel(form, text="Auto-Launch App on Desktop (Optional):", font=ctk.CTkFont(size=13, weight="bold")).grid(
            row=4, column=0, sticky="w", pady=7, padx=(0, 14)
        )
        self.dex_start_app_entry = ctk.CTkEntry(
            form,
            placeholder_text="Leave blank for Desktop Launcher, or e.g. com.android.chrome",
            fg_color="#0b0e14",
        )
        self.dex_start_app_entry.grid(row=4, column=1, sticky="ew", pady=7)

        dex_flags = ctk.CTkFrame(left_card, fg_color="#0e131d", corner_radius=10)
        dex_flags.pack(fill="x", padx=18, pady=10)

        self.dex_force_settings = ctk.CTkCheckBox(
            dex_flags,
            text="Enable Android Global Desktop Mode & Freeform Multi-Window Flags (force_desktop_mode_on_external_displays)",
        )
        self.dex_force_settings.select()
        self.dex_force_settings.pack(anchor="w", padx=14, pady=(10, 5))

        self.dex_keep_content = ctk.CTkCheckBox(
            dex_flags,
            text="Preserve Running Apps on Main Screen When Closing Desktop Session (--no-vd-destroy-content)",
        )
        self.dex_keep_content.select()
        self.dex_keep_content.pack(anchor="w", padx=14, pady=5)

        self.dex_fullscreen = ctk.CTkCheckBox(
            dex_flags,
            text="Launch PC Desktop Session in Fullscreen Monitor Mode (--fullscreen)",
        )
        self.dex_fullscreen.pack(anchor="w", padx=14, pady=(5, 10))

        dex_btns = ctk.CTkFrame(left_card, fg_color="transparent")
        dex_btns.pack(fill="x", padx=18, pady=(6, 14))

        ctk.CTkButton(
            dex_btns,
            text="  LAUNCH PC DEX / DESKTOP WORKSTATION",
            image=self.icons.get("dex", 20, (255, 255, 255, 255)),
            height=44,
            corner_radius=10,
            fg_color="#0284c7",
            hover_color="#0369a1",
            font=ctk.CTkFont(size=14, weight="bold"),
            command=self.start_dex_desktop_mode,
        ).pack(side="left", fill="x", expand=True, padx=(0, 8))

        ctk.CTkButton(
            dex_btns,
            text="  STOP DESKTOP",
            image=self.icons.get("stop", 18, (255, 255, 255, 255)),
            height=44,
            width=165,
            corner_radius=10,
            fg_color="#be123c",
            hover_color="#9f1239",
            font=ctk.CTkFont(size=13, weight="bold"),
            command=self.stop_dex_desktop_mode,
        ).pack(side="left")

        right_card = ctk.CTkFrame(
            container, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b", width=360
        )
        right_card.pack(side="right", fill="y", padx=(8, 0), pady=4)
        right_card.pack_propagate(False)

        ctk.CTkLabel(
            right_card,
            text="Desktop Mode Telemetry & Flags",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color="#38bdf8",
        ).pack(anchor="w", padx=18, pady=(16, 8))

        info_text = (
            "Supported Devices:\n"
            "• Google Pixel 8 / 8 Pro / 9 (Android 14–17 Desktop Taskbar & Freeform Windows)\n"
            "• Samsung Galaxy S / Note / Fold / Tab Series (DeX Virtual Display)\n"
            "• Motorola Ready For / Lenovo Smart Connect\n"
            "• Xiaomi / OnePlus / AOSP 13+ Freeform Mode"
        )
        ctk.CTkLabel(
            right_card,
            text=info_text,
            font=ctk.CTkFont(size=12),
            text_color="#cbd5e1",
            justify="left",
        ).pack(anchor="w", padx=18, pady=6)

        ctk.CTkButton(
            right_card,
            text="Apply Android Desktop & Freeform Flags Now",
            height=36,
            fg_color="#0d9488",
            hover_color="#0f766e",
            command=lambda: self._set_android_desktop_flags(True),
        ).pack(fill="x", padx=18, pady=(14, 6))

        ctk.CTkButton(
            right_card,
            text="Reset Android Desktop Flags to Default",
            height=36,
            fg_color="#334155",
            hover_color="#475569",
            command=lambda: self._set_android_desktop_flags(False),
        ).pack(fill="x", padx=18, pady=6)

        self.dex_status_box = ctk.CTkTextbox(
            right_card,
            height=220,
            fg_color="#090c12",
            text_color="#38bdf8",
            font=ctk.CTkFont(family="Consolas", size=11),
        )
        self.dex_status_box.pack(fill="both", expand=True, padx=18, pady=(10, 14))
        self._log_dex("Ready to launch Virtual External Desktop Display.")

    # -------------------------------------------------------------------------
    # TAB 3: LIVE SYSTEM MONITOR & TASK MANAGER (WITH RADIAL GAUGES + SPARKLINES)
    # -------------------------------------------------------------------------
    def _init_tab_system_monitor(self) -> None:
        cards_row = ctk.CTkFrame(self.tab_monitor, fg_color="transparent")
        cards_row.pack(fill="x", padx=6, pady=(4, 8))
        cards_row.grid_columnconfigure((0, 1, 2), weight=1)

        cpu_card = ctk.CTkFrame(cards_row, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b")
        cpu_card.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        top_c1 = ctk.CTkFrame(cpu_card, fg_color="transparent")
        top_c1.pack(fill="x", padx=10, pady=(6, 0))
        self.gauge_cpu = tk.Canvas(top_c1, width=76, height=76, bg="#131926", highlightthickness=0)
        self.gauge_cpu.pack(side="left", padx=(2, 8))
        c1_txt = ctk.CTkFrame(top_c1, fg_color="transparent")
        c1_txt.pack(side="left", fill="both", expand=True, pady=10)
        self.lbl_cpu_val = ctk.CTkLabel(
            c1_txt, text="CPU Utilization: 0.0%", font=ctk.CTkFont(size=14, weight="bold"), text_color="#38bdf8"
        )
        self.lbl_cpu_val.pack(anchor="w")
        self.lbl_tasks_val = ctk.CTkLabel(
            c1_txt, text="Processes: 0 Total (0 Running)", font=ctk.CTkFont(size=11), text_color="#94a3b8"
        )
        self.lbl_tasks_val.pack(anchor="w")
        self.canvas_cpu = tk.Canvas(cpu_card, height=48, bg="#0b0e14", highlightthickness=0)
        self.canvas_cpu.pack(fill="x", padx=12, pady=(2, 10))

        ram_card = ctk.CTkFrame(cards_row, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b")
        ram_card.grid(row=0, column=1, sticky="ew", padx=6)
        top_c2 = ctk.CTkFrame(ram_card, fg_color="transparent")
        top_c2.pack(fill="x", padx=10, pady=(6, 0))
        self.gauge_ram = tk.Canvas(top_c2, width=76, height=76, bg="#131926", highlightthickness=0)
        self.gauge_ram.pack(side="left", padx=(2, 8))
        c2_txt = ctk.CTkFrame(top_c2, fg_color="transparent")
        c2_txt.pack(side="left", fill="both", expand=True, pady=10)
        self.lbl_ram_val = ctk.CTkLabel(
            c2_txt, text="RAM: 0 MB / 0 MB (0.0%)", font=ctk.CTkFont(size=14, weight="bold"), text_color="#a855f7"
        )
        self.lbl_ram_val.pack(anchor="w")
        self.lbl_swap_val = ctk.CTkLabel(
            c2_txt, text="ZRAM / Swap: 0 MB / 0 MB", font=ctk.CTkFont(size=11), text_color="#94a3b8"
        )
        self.lbl_swap_val.pack(anchor="w")
        self.canvas_ram = tk.Canvas(ram_card, height=48, bg="#0b0e14", highlightthickness=0)
        self.canvas_ram.pack(fill="x", padx=12, pady=(2, 10))

        bat_card = ctk.CTkFrame(cards_row, fg_color="#131926", corner_radius=12, border_width=1, border_color="#1e293b")
        bat_card.grid(row=0, column=2, sticky="ew", padx=(6, 0))
        top_c3 = ctk.CTkFrame(bat_card, fg_color="transparent")
        top_c3.pack(fill="x", padx=10, pady=(6, 0))
        self.gauge_temp = tk.Canvas(top_c3, width=76, height=76, bg="#131926", highlightthickness=0)
        self.gauge_temp.pack(side="left", padx=(2, 8))
        c3_txt = ctk.CTkFrame(top_c3, fg_color="transparent")
        c3_txt.pack(side="left", fill="both", expand=True, pady=10)
        self.lbl_bat_val = ctk.CTkLabel(
            c3_txt, text="Battery: --% | Temp: -- °C", font=ctk.CTkFont(size=14, weight="bold"), text_color="#10b981"
        )
        self.lbl_bat_val.pack(anchor="w")
        self.lbl_mon_state = ctk.CTkLabel(
            c3_txt, text="Live Telemetry Polling: Active (2.0s)", font=ctk.CTkFont(size=11), text_color="#94a3b8"
        )
        self.lbl_mon_state.pack(anchor="w")
        self.canvas_temp = tk.Canvas(bat_card, height=48, bg="#0b0e14", highlightthickness=0)
        self.canvas_temp.pack(fill="x", padx=12, pady=(2, 10))

        tm_bar = ctk.CTkFrame(self.tab_monitor, fg_color="#131926", corner_radius=10)
        tm_bar.pack(fill="x", padx=6, pady=(0, 6))

        ctk.CTkLabel(
            tm_bar,
            text="Filter Process / Package:",
            font=ctk.CTkFont(size=12, weight="bold"),
        ).pack(side="left", padx=(14, 6), pady=8)

        self.proc_filter_var = ctk.StringVar(value="")
        self.proc_filter_entry = ctk.CTkEntry(
            tm_bar,
            textvariable=self.proc_filter_var,
            placeholder_text="e.g. com.android, system_server, youtube...",
            width=260,
            fg_color="#0b0e14",
        )
        self.proc_filter_entry.pack(side="left", padx=4, pady=8)

        self.pause_mon_btn = ctk.CTkButton(
            tm_bar,
            text="Pause Live Poll",
            image=self.icons.get("stop", 16, (255, 255, 255, 255)),
            width=140,
            fg_color="#334155",
            hover_color="#475569",
            command=self._toggle_monitor_pause,
        )
        self.pause_mon_btn.pack(side="left", padx=8, pady=8)

        ctk.CTkButton(
            tm_bar,
            text="Force-Stop Selected App",
            image=self.icons.get("stop", 16, (255, 255, 255, 255)),
            width=195,
            fg_color="#be123c",
            hover_color="#9f1239",
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._force_stop_selected_process,
        ).pack(side="right", padx=12, pady=8)

        ctk.CTkButton(
            tm_bar,
            text="Trim Memory Caches",
            image=self.icons.get("refresh", 16, (255, 255, 255, 255)),
            width=170,
            fg_color="#0284c7",
            hover_color="#0369a1",
            command=self._trim_device_memory,
        ).pack(side="right", padx=4, pady=8)

        table_frame = ctk.CTkFrame(self.tab_monitor, fg_color="#10141d", corner_radius=10)
        table_frame.pack(fill="both", expand=True, padx=6, pady=(0, 4))

        cols = ("pid", "user", "cpu", "mem", "res", "state", "time", "name")
        self.proc_tree = ttk.Treeview(table_frame, columns=cols, show="headings", style="Studio.Treeview")
        headings = [
            ("pid", "PID", 70, "center"),
            ("user", "USER", 100, "w"),
            ("cpu", "CPU %", 85, "e"),
            ("mem", "MEM %", 85, "e"),
            ("res", "RSS RAM", 95, "e"),
            ("state", "STATE", 65, "center"),
            ("time", "CPU TIME", 100, "e"),
            ("name", "PACKAGE / PROCESS NAME", 460, "w"),
        ]
        for col_id, title_txt, width, anchor in headings:
            self.proc_tree.heading(col_id, text=title_txt)
            self.proc_tree.column(col_id, width=width, anchor=anchor)

        scroll_y = ttk.Scrollbar(table_frame, orient="vertical", command=self.proc_tree.yview)
        self.proc_tree.configure(yscrollcommand=scroll_y.set)
        self.proc_tree.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")

    # -------------------------------------------------------------------------
    # TAB 4: APP MANAGER (INSTALL / UNINSTALL / LIST / LAUNCH APKS)
    # -------------------------------------------------------------------------
    def _init_tab_app_manager(self) -> None:
        top_controls = ctk.CTkFrame(self.tab_apps, fg_color="#131926", corner_radius=10)
        top_controls.pack(fill="x", padx=6, pady=(4, 6))

        ctk.CTkLabel(top_controls, text="Filter:", font=ctk.CTkFont(size=12, weight="bold")).pack(
            side="left", padx=(12, 6), pady=10
        )

        self.app_type_var = ctk.StringVar(value="User / 3rd-Party Apps (-3)")
        self.app_type_menu = ctk.CTkOptionMenu(
            top_controls,
            variable=self.app_type_var,
            values=["User / 3rd-Party Apps (-3)", "System Packages (-s)", "All Installed Packages"],
            command=lambda _: self.refresh_packages_list(),
            width=210,
            fg_color="#1e293b",
        )
        self.app_type_menu.pack(side="left", padx=6, pady=10)

        self.app_search_var = ctk.StringVar(value="")
        self.app_search_var.trace_add("write", lambda *_: self._filter_packages_tree())
        self.app_search_entry = ctk.CTkEntry(
            top_controls,
            textvariable=self.app_search_var,
            placeholder_text="Search package name...",
            width=240,
            fg_color="#0b0e14",
        )
        self.app_search_entry.pack(side="left", padx=8, pady=10)

        ctk.CTkButton(
            top_controls,
            text="Refresh Apps",
            image=self.icons.get("refresh", 16, (56, 189, 248, 255)),
            width=130,
            fg_color="#1e293b",
            hover_color="#334155",
            command=self.refresh_packages_list,
        ).pack(side="left", padx=6, pady=10)

        ctk.CTkButton(
            top_controls,
            text="Install APK(s)...",
            image=self.icons.get("download", 18, (255, 255, 255, 255)),
            width=175,
            fg_color="#0284c7",
            hover_color="#0369a1",
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._install_apk_dialog,
        ).pack(side="right", padx=12, pady=10)

        act_bar = ctk.CTkFrame(self.tab_apps, fg_color="#131926", corner_radius=10)
        act_bar.pack(fill="x", padx=6, pady=(0, 6))

        self.lbl_pkg_count = ctk.CTkLabel(
            act_bar,
            text="Packages Loaded: 0",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#38bdf8",
        )
        self.lbl_pkg_count.pack(side="left", padx=14, pady=8)

        ctk.CTkButton(
            act_bar,
            text="Uninstall App",
            image=self.icons.get("trash", 16, (255, 255, 255, 255)),
            width=145,
            fg_color="#be123c",
            hover_color="#9f1239",
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._uninstall_selected_package,
        ).pack(side="right", padx=(6, 12), pady=8)

        ctk.CTkButton(
            act_bar,
            text="Clear Data & Cache",
            width=150,
            fg_color="#b45309",
            hover_color="#92400e",
            command=self._clear_selected_package_data,
        ).pack(side="right", padx=6, pady=8)

        ctk.CTkButton(
            act_bar,
            text="Force Stop",
            width=110,
            fg_color="#334155",
            hover_color="#475569",
            command=self._force_stop_selected_package,
        ).pack(side="right", padx=6, pady=8)

        ctk.CTkButton(
            act_bar,
            text="Backup / Pull APK",
            image=self.icons.get("download", 16, (255, 255, 255, 255)),
            width=155,
            fg_color="#0d9488",
            hover_color="#0f766e",
            command=self._pull_selected_apk,
        ).pack(side="right", padx=6, pady=8)

        ctk.CTkButton(
            act_bar,
            text="Launch on Phone",
            image=self.icons.get("play", 16, (255, 255, 255, 255)),
            width=150,
            fg_color="#0284c7",
            hover_color="#0369a1",
            command=self._launch_selected_package,
        ).pack(side="right", padx=6, pady=8)

        ctk.CTkButton(
            act_bar,
            text="Launch in DeX Window",
            image=self.icons.get("dex", 16, (255, 255, 255, 255)),
            width=175,
            fg_color="#6366f1",
            hover_color="#4f46e5",
            command=self._launch_selected_package_in_dex,
        ).pack(side="right", padx=6, pady=8)

        pkg_frame = ctk.CTkFrame(self.tab_apps, fg_color="#10141d", corner_radius=10)
        pkg_frame.pack(fill="both", expand=True, padx=6, pady=(0, 4))

        self.pkg_tree = ttk.Treeview(
            pkg_frame,
            columns=("package", "type"),
            show="headings",
            style="Studio.Treeview",
        )
        self.pkg_tree.heading("package", text="APPLICATION PACKAGE IDENTIFIER")
        self.pkg_tree.column("package", width=750, anchor="w")
        self.pkg_tree.heading("type", text="CATEGORY")
        self.pkg_tree.column("type", width=180, anchor="center")

        pkg_scroll = ttk.Scrollbar(pkg_frame, orient="vertical", command=self.pkg_tree.yview)
        self.pkg_tree.configure(yscrollcommand=pkg_scroll.set)
        self.pkg_tree.pack(side="left", fill="both", expand=True)
        pkg_scroll.pack(side="right", fill="y")

    # -------------------------------------------------------------------------
    # TAB 5: DEVICE HARDWARE & OS INFO
    # -------------------------------------------------------------------------
    def _init_tab_device_info(self) -> None:
        bar = ctk.CTkFrame(self.tab_info, fg_color="#131926", corner_radius=10)
        bar.pack(fill="x", padx=6, pady=(4, 6))

        ctk.CTkLabel(
            bar,
            text="  Complete Android Device Hardware, SoC, Display & Battery Telemetry",
            image=self.icons.get("info", 20, (56, 189, 248, 255)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color="#38bdf8",
        ).pack(side="left", padx=14, pady=10)

        ctk.CTkButton(
            bar,
            text="Refresh Hardware Specs",
            image=self.icons.get("refresh", 16, (255, 255, 255, 255)),
            width=190,
            fg_color="#0284c7",
            hover_color="#0369a1",
            command=self.refresh_device_info,
        ).pack(side="right", padx=12, pady=10)

        ctk.CTkButton(
            bar,
            text="Copy JSON Report",
            width=150,
            fg_color="#1e293b",
            hover_color="#334155",
            command=self._copy_device_info_clipboard,
        ).pack(side="right", padx=6, pady=10)

        info_frame = ctk.CTkFrame(self.tab_info, fg_color="#10141d", corner_radius=10)
        info_frame.pack(fill="both", expand=True, padx=6, pady=(0, 4))

        self.info_tree = ttk.Treeview(
            info_frame,
            columns=("prop", "val"),
            show="headings",
            style="Studio.Treeview",
        )
        self.info_tree.heading("prop", text="HARDWARE / SYSTEM PROPERTY")
        self.info_tree.column("prop", width=320, anchor="w")
        self.info_tree.heading("val", text="LIVE VALUE")
        self.info_tree.column("val", width=700, anchor="w")

        info_scroll = ttk.Scrollbar(info_frame, orient="vertical", command=self.info_tree.yview)
        self.info_tree.configure(yscrollcommand=info_scroll.set)
        self.info_tree.pack(side="left", fill="both", expand=True)
        info_scroll.pack(side="right", fill="y")

    # =========================================================================
    # STATUS FOOTER
    # =========================================================================
    def _build_status_footer(self) -> None:
        self.footer = ctk.CTkFrame(self, fg_color="#111621", corner_radius=8, height=32)
        self.footer.pack(fill="x", padx=14, pady=(0, 10))

        self.status_label = ctk.CTkLabel(
            self.footer,
            text=f"Ready | ADB: {self.adb.adb_path} | Scrcpy: {self.adb.scrcpy_path}",
            font=ctk.CTkFont(size=11),
            text_color="#94a3b8",
        )
        self.status_label.pack(side="left", padx=12, pady=4)

    def set_status(self, msg: str, color: str = "#38bdf8") -> None:
        self.status_label.configure(text=msg, text_color=color)

    # =========================================================================
    # DEVICE DISCOVERY & WIRELESS ADB
    # =========================================================================
    def refresh_devices(self) -> None:
        def worker() -> None:
            devs = self.adb.list_devices()
            self.after(0, lambda: self._update_device_dropdown(devs))

        threading.Thread(target=worker, daemon=True).start()

    def _update_device_dropdown(self, devs: List[Dict[str, str]]) -> None:
        self.devices_cache = devs
        if not devs:
            self.device_combo.configure(values=["No ADB Devices Connected"])
            self.device_combo.set("No ADB Devices Connected")
            self.current_serial = None
            self.monitor.active_serial = None
            self.set_status("No active ADB devices found. Connect via USB or Wi-Fi ADB.", "#f43f5e")
            return

        labels = [f"{d['serial']} ({d['model']} - {d['state']})" for d in devs]
        self.device_combo.configure(values=labels)
        self.device_combo.set(labels[0])
        self._on_device_selected(labels[0])

    def _on_device_selected(self, selection: str) -> None:
        if not self.devices_cache or selection == "No ADB Devices Connected":
            return
        serial = selection.split()[0].strip()
        self.current_serial = serial
        self.monitor.active_serial = serial
        self.set_status(f"Active Target Device: {selection}", "#10b981")
        self.refresh_device_info()
        self.refresh_packages_list()

    def _connect_wireless_adb(self) -> None:
        addr = self.wireless_entry.get().strip()
        if not addr:
            messagebox.showwarning("Wireless ADB", "Enter target device IP:Port (e.g., 192.168.8.246:5555)")
            return
        if ":" not in addr:
            addr += ":5555"

        def worker() -> None:
            code, out, err = self.adb.run_adb(["connect", addr], timeout=6.0)
            msg = out or err
            self.after(0, lambda: self.set_status(f"Wi-Fi Connect ({addr}): {msg}", "#38bdf8"))
            self.refresh_devices()

        threading.Thread(target=worker, daemon=True).start()

    def _enable_tcpip_5555(self) -> None:
        if not self.current_serial:
            return

        def worker() -> None:
            code, out, err = self.adb.run_adb(["tcpip", "5555"], serial=self.current_serial, timeout=5.0)
            msg = out or err or "TCP/IP port 5555 enabled"
            self.after(0, lambda: self.set_status(f"ADB TCP/IP: {msg}", "#10b981"))

        threading.Thread(target=worker, daemon=True).start()

    # =========================================================================
    # EMULATOR NAVIGATION & HARDWARE BUTTON DISPATCH (FROM SIDE-TOOLBAR)
    # =========================================================================
    def _handle_nav_button(self, action: str) -> None:
        serial = self.current_serial
        if not serial:
            self.set_status("No device connected for navigation input.", "#f43f5e")
            return

        def worker() -> None:
            if action == "cmd_notif":
                self.adb.run_adb(["shell", "cmd", "statusbar", "expand-notifications"], serial=serial)
                self.after(0, lambda: self.set_status("Expanded notifications shade on device.", "#38bdf8"))
            elif action == "cmd_qsettings":
                self.adb.run_adb(["shell", "cmd", "statusbar", "expand-settings"], serial=serial)
                self.after(0, lambda: self.set_status("Expanded quick settings panel on device.", "#38bdf8"))
            elif action == "cmd_screen":
                self._capture_device_screenshot(serial)
            elif action == "cmd_rotate":
                self._rotation_state = (self._rotation_state + 1) % 4
                self.adb.run_adb(
                    [
                        "shell",
                        f"settings put system accelerometer_rotation 0; settings put system user_rotation {self._rotation_state}",
                    ],
                    serial=serial,
                )
                self.after(0, lambda: self.set_status(f"Rotated screen orientation ({self._rotation_state * 90}°)", "#38bdf8"))
            else:
                self.adb.send_keyevent(serial, action)
                self.after(0, lambda: self.set_status(f"Sent Android KeyEvent {action} to {serial}", "#38bdf8"))

        threading.Thread(target=worker, daemon=True).start()

    def _capture_device_screenshot(self, serial: str) -> None:
        ts = time.strftime("%Y%m%d_%H%M%S")
        out_dir = os.path.join(os.path.expanduser("~"), "Pictures", "AndroidScrcpyStudio")
        os.makedirs(out_dir, exist_ok=True)
        local_path = os.path.join(out_dir, f"screen_{serial}_{ts}.png")
        remote_tmp = "/sdcard/jarvis_screen_tmp.png"
        code, _, _ = self.adb.run_adb(["shell", "screencap", "-p", remote_tmp], serial=serial, timeout=6.0)
        if code == 0:
            self.adb.run_adb(["pull", remote_tmp, local_path], serial=serial, timeout=6.0)
            self.adb.run_adb(["shell", "rm", "-f", remote_tmp], serial=serial, timeout=3.0)
            self.after(0, lambda: self.set_status(f"Screenshot saved: {local_path}", "#10b981"))

    def _send_text_to_device(self) -> None:
        serial = self.current_serial
        text = self.inject_text_entry.get()
        if not serial or not text:
            return
        escaped = text.replace(" ", "%s").replace("'", r"\'").replace('"', r"\"")

        def worker() -> None:
            self.adb.run_adb(["shell", "input", "text", escaped], serial=serial, timeout=4.0)
            self.after(0, lambda: self.set_status(f"Injected text to {serial}", "#10b981"))

        threading.Thread(target=worker, daemon=True).start()

    # =========================================================================
    # SCRCPY MIRROR ENGINE + MAGNETIC EMULATOR SIDE-TOOLBAR
    # =========================================================================
    def start_scrcpy_mirror(self) -> None:
        if not self.current_serial:
            messagebox.showwarning("Scrcpy Mirror", "Connect and select an ADB device first.")
            return

        self.stop_scrcpy_mirror()

        win_title = f"Scrcpy Mirror — {self.current_serial}"
        cmd = [self.adb.scrcpy_path, "-s", self.current_serial]

        res_choice = self.mirror_res_var.get()
        m_res = re.search(r"^(\d+)", res_choice)
        if m_res:
            cmd.extend([f"--max-size={m_res.group(1)}"])

        vbit = self.mirror_vbit_var.get().split()[0]
        cmd.extend([f"--video-bit-rate={vbit}"])

        fps = self.mirror_fps_var.get()
        cmd.extend([f"--max-fps={fps}"])

        vcodec = self.mirror_vcodec_var.get()
        cmd.extend([f"--video-codec={vcodec}"])

        if self.mirror_no_audio.get():
            cmd.append("--no-audio")
        else:
            abit = self.mirror_abit_var.get().split()[0]
            acodec = self.mirror_acodec_var.get()
            cmd.extend([f"--audio-bit-rate={abit}", f"--audio-codec={acodec}"])

        if self.mirror_turn_screen_off.get():
            cmd.append("--turn-screen-off")
        if self.mirror_stay_awake.get():
            cmd.append("--stay-awake")
        if self.mirror_always_top.get():
            cmd.append("--always-on-top")
        if self.mirror_show_touches.get():
            cmd.append("--show-touches")

        cmd.append(f"--window-title={win_title}")

        try:
            env = os.environ.copy()
            env["ADB"] = self.adb.adb_path
            scrcpy_dir = os.path.dirname(self.adb.scrcpy_path)
            srv_candidate = os.path.join(scrcpy_dir, "scrcpy-server")
            if os.path.isfile(srv_candidate):
                env["SCRCPY_SERVER_PATH"] = srv_candidate
            self.scrcpy_mirror_proc = subprocess.Popen(
                cmd,
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                **get_subprocess_kwargs(),
            )

            # Spawn Magnetic Android Emulator Side-Toolbar docked alongside the Scrcpy Mirror window
            if self.mirror_attach_sidebar.get():
                self.emulator_sidebar = ScrcpyEmulatorSideBar(
                    self,
                    self.icons,
                    win_title,
                    self.scrcpy_mirror_proc,
                    self._handle_nav_button,
                )

            self.set_status(
                f"Scrcpy Mirror Active (PID {self.scrcpy_mirror_proc.pid}) with Magnetic Emulator Side-Toolbar",
                "#10b981",
            )
        except Exception as exc:
            messagebox.showerror("Scrcpy Launch Error", f"Failed to launch scrcpy:\n{exc}")

    def stop_scrcpy_mirror(self) -> None:
        if self.emulator_sidebar is not None:
            self.emulator_sidebar.close_bar()
            self.emulator_sidebar = None
        if self.scrcpy_mirror_proc and self.scrcpy_mirror_proc.poll() is None:
            try:
                self.scrcpy_mirror_proc.terminate()
            except Exception:
                pass
            self.scrcpy_mirror_proc = None
            self.set_status("Scrcpy Mirror stopped.", "#f59e0b")

    # =========================================================================
    # PC DEX / DESKTOP WORKSTATION ENGINE
    # =========================================================================
    def _log_dex(self, text: str) -> None:
        ts = time.strftime("%H:%M:%S")
        self.dex_status_box.insert("end", f"[{ts}] {text}\n")
        self.dex_status_box.see("end")

    def _set_android_desktop_flags(self, enable: bool) -> None:
        serial = self.current_serial
        if not serial:
            return
        val = "1" if enable else "0"

        def worker() -> None:
            cmds = [
                f"settings put global force_desktop_mode_on_external_displays {val}",
                f"settings put global enable_freeform_support {val}",
                f"settings put global force_resizable_activities {val}",
                f"settings put global enable_non_resizable_multi_window {val}",
            ]
            self.adb.run_adb(["shell", "; ".join(cmds)], serial=serial, timeout=5.0)
            state_str = "ENABLED" if enable else "RESET"
            self.after(0, lambda: self._log_dex(f"Android Desktop & Freeform window flags {state_str} on {serial}."))

        threading.Thread(target=worker, daemon=True).start()

    def start_dex_desktop_mode(self, start_package: Optional[str] = None) -> None:
        if not self.current_serial:
            messagebox.showwarning("PC DeX Mode", "Connect and select an ADB device first.")
            return

        self.stop_dex_desktop_mode()

        if self.dex_force_settings.get():
            self._set_android_desktop_flags(True)

        res = self.dex_res_var.get().split()[0]
        dpi = self.dex_dpi_var.get().split()[0]
        fps = self.dex_fps_var.get()
        vbit = self.dex_vbit_var.get()

        cmd = [
            self.adb.scrcpy_path,
            "-s",
            self.current_serial,
            f"--new-display={res}/{dpi}",
            f"--max-fps={fps}",
            f"--video-bit-rate={vbit}",
            f"--window-title=J.A.R.V.I.S. DeX Desktop Mode — {self.current_serial} ({res} @ {dpi} DPI)",
        ]

        if self.dex_keep_content.get():
            cmd.append("--no-vd-destroy-content")
        if self.dex_fullscreen.get():
            cmd.append("--fullscreen")

        pkg = start_package or self.dex_start_app_entry.get().strip()
        if pkg:
            cmd.append(f"--start-app=+{pkg}")

        try:
            env = os.environ.copy()
            env["ADB"] = self.adb.adb_path
            scrcpy_dir = os.path.dirname(self.adb.scrcpy_path)
            srv_candidate = os.path.join(scrcpy_dir, "scrcpy-server")
            if os.path.isfile(srv_candidate):
                env["SCRCPY_SERVER_PATH"] = srv_candidate
            self.scrcpy_dex_proc = subprocess.Popen(
                cmd,
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                **get_subprocess_kwargs(),
            )
            self._log_dex(f"Launched Virtual Desktop Display: {res}/{dpi} DPI @ {fps} FPS (PID {self.scrcpy_dex_proc.pid})")
            self.set_status(f"PC DeX Desktop Session Active (PID {self.scrcpy_dex_proc.pid})", "#10b981")
        except Exception as exc:
            self._log_dex(f"ERROR launching DeX Desktop: {exc}")
            messagebox.showerror("DeX Mode Error", str(exc))

    def stop_dex_desktop_mode(self) -> None:
        if self.scrcpy_dex_proc and self.scrcpy_dex_proc.poll() is None:
            try:
                self.scrcpy_dex_proc.terminate()
            except Exception:
                pass
            self.scrcpy_dex_proc = None
            self._log_dex("Stopped Virtual Desktop Display session.")
            self.set_status("PC DeX Desktop session stopped.", "#f59e0b")

    # =========================================================================
    # LIVE SYSTEM TASK MANAGER & SPARKLINE RENDERER
    # =========================================================================
    def _draw_sparkline(
        self, canvas: tk.Canvas, data: deque, stroke_color: str, fill_color: str, max_val: float = 100.0
    ) -> None:
        canvas.delete("all")
        w = max(canvas.winfo_width(), 200)
        h = max(canvas.winfo_height(), 46)
        pts = list(data)
        if len(pts) < 2:
            return

        step_x = w / (len(pts) - 1)
        coords: List[float] = []
        for idx, val in enumerate(pts):
            x = idx * step_x
            norm = max(0.0, min(1.0, val / max(max_val, 1.0)))
            y = h - (norm * (h - 8)) - 4
            coords.extend([x, y])

        poly_coords = [0, h] + coords + [w, h]
        canvas.create_polygon(poly_coords, fill=fill_color, outline="")
        canvas.create_line(coords, fill=stroke_color, width=2, smooth=True)

    def _periodic_table_sync(self) -> None:
        with self.monitor.lock:
            cpu_pct = self.monitor.cpu_total_pct
            ram_used = self.monitor.ram_used_mb
            ram_tot = self.monitor.ram_total_mb
            ram_pct = self.monitor.ram_pct
            swap_used = self.monitor.swap_used_mb
            swap_tot = self.monitor.swap_total_mb
            bat_lvl = self.monitor.battery_level
            bat_temp = self.monitor.battery_temp_c
            t_tot = self.monitor.tasks_total
            t_run = self.monitor.tasks_running
            procs = list(self.monitor.processes)
            h_cpu = deque(self.monitor.history_cpu)
            h_ram = deque(self.monitor.history_ram)
            h_temp = deque(self.monitor.history_temp)

        self.lbl_cpu_val.configure(text=f"CPU Utilization: {cpu_pct:.1f}%")
        self.lbl_tasks_val.configure(text=f"Processes: {t_tot} Total ({t_run} Running)")
        self.lbl_ram_val.configure(text=f"RAM: {ram_used:.0f} MB / {ram_tot:.0f} MB ({ram_pct:.1f}%)")
        self.lbl_swap_val.configure(text=f"ZRAM / Swap: {swap_used:.0f} MB / {swap_tot:.0f} MB")
        self.lbl_bat_val.configure(text=f"Battery: {bat_lvl}% | Temp: {bat_temp:.1f} °C")

        self._draw_sparkline(self.canvas_cpu, h_cpu, "#38bdf8", "#0c2d48", 100.0)
        self._draw_sparkline(self.canvas_ram, h_ram, "#a855f7", "#2e1045", 100.0)
        self._draw_sparkline(self.canvas_temp, h_temp, "#10b981", "#093024", 60.0)

        selected_pid = None
        sel = self.proc_tree.selection()
        if sel:
            item_vals = self.proc_tree.item(sel[0], "values")
            if item_vals:
                selected_pid = str(item_vals[0])

        flt = self.proc_filter_var.get().strip().lower()
        self.proc_tree.delete(*self.proc_tree.get_children())
        for p in procs:
            if flt and flt not in p["name"].lower() and flt not in str(p["pid"]) and flt not in p["user"].lower():
                continue
            iid = self.proc_tree.insert(
                "",
                "end",
                values=(
                    p["pid"],
                    p["user"],
                    f"{p['cpu']:.1f}%",
                    f"{p['mem']:.1f}%",
                    p["res"],
                    p["state"],
                    p["time"],
                    p["name"],
                ),
            )
            if selected_pid and str(p["pid"]) == selected_pid:
                self.proc_tree.selection_set(iid)

        self.after(2000, self._periodic_table_sync)

    def _toggle_monitor_pause(self) -> None:
        self.monitor.paused = not self.monitor.paused
        if self.monitor.paused:
            self.pause_mon_btn.configure(text="Resume Live Poll", fg_color="#0284c7")
            self.lbl_mon_state.configure(text="Live Telemetry Polling: PAUSED", text_color="#f59e0b")
        else:
            self.pause_mon_btn.configure(text="Pause Live Poll", fg_color="#334155")
            self.lbl_mon_state.configure(text="Live Telemetry Polling: Active (2.0s)", text_color="#94a3b8")

    def _force_stop_selected_process(self) -> None:
        if not self.current_serial:
            return
        sel = self.proc_tree.selection()
        if not sel:
            messagebox.showinfo("Task Manager", "Select a process row in the table first.")
            return
        vals = self.proc_tree.item(sel[0], "values")
        pid, proc_name = vals[0], vals[7]
        pkg_candidate = proc_name.split(":")[0].split()[0]

        def worker() -> None:
            if "." in pkg_candidate and not pkg_candidate.startswith("/"):
                self.adb.run_adb(["shell", "am", "force-stop", pkg_candidate], serial=self.current_serial)
                msg = f"Force-stopped package {pkg_candidate} (PID {pid})"
            else:
                self.adb.run_adb(["shell", "kill", "-9", str(pid)], serial=self.current_serial)
                msg = f"Sent SIGKILL to PID {pid} ({proc_name})"
            self.after(0, lambda: self.set_status(msg, "#f43f5e"))
            self.monitor.poll_once()

        threading.Thread(target=worker, daemon=True).start()

    def _trim_device_memory(self) -> None:
        if not self.current_serial:
            return

        def worker() -> None:
            self.adb.run_adb(
                ["shell", "am", "send-trim-memory", "--user", "0", "RUNNING_CRITICAL"], serial=self.current_serial
            )
            self.after(0, lambda: self.set_status("Dispatched memory trim request to running user processes.", "#10b981"))

        threading.Thread(target=worker, daemon=True).start()

    # =========================================================================
    # APP MANAGER (INSTALL / UNINSTALL / LIST / BACKUP / LAUNCH)
    # =========================================================================
    def refresh_packages_list(self) -> None:
        serial = self.current_serial
        if not serial:
            return

        mode = self.app_type_var.get()
        flag = "-3"
        category = "User Installed"
        if "-s" in mode:
            flag = "-s"
            category = "System Package"
        elif "All" in mode:
            flag = ""
            category = "All Packages"

        def worker() -> None:
            args = ["shell", "pm", "list", "packages"]
            if flag:
                args.append(flag)
            code, out, _ = self.adb.run_adb(args, serial=serial, timeout=8.0)
            pkgs: List[str] = []
            if code == 0 and out:
                for line in out.splitlines():
                    line = line.strip()
                    if line.startswith("package:"):
                        pkgs.append(line.replace("package:", "").strip())
            pkgs.sort()
            self.packages_cache = pkgs
            self.after(0, lambda: self._populate_packages_tree(category))

        threading.Thread(target=worker, daemon=True).start()

    def _populate_packages_tree(self, category: str) -> None:
        self._filter_packages_tree(category)

    def _filter_packages_tree(self, category: str = "Application") -> None:
        query = self.app_search_var.get().strip().lower()
        self.pkg_tree.delete(*self.pkg_tree.get_children())
        count = 0
        for pkg in self.packages_cache:
            if query and query not in pkg.lower():
                continue
            self.pkg_tree.insert("", "end", values=(pkg, category))
            count += 1
        self.lbl_pkg_count.configure(text=f"Packages Loaded: {count}")

    def _get_selected_package(self) -> Optional[str]:
        sel = self.pkg_tree.selection()
        if not sel:
            messagebox.showinfo("App Manager", "Select an application package from the list first.")
            return None
        vals = self.pkg_tree.item(sel[0], "values")
        return vals[0] if vals else None

    def _install_apk_dialog(self) -> None:
        if not self.current_serial:
            messagebox.showwarning("App Manager", "Connect and select an ADB device first.")
            return
        apk_paths = filedialog.askopenfilenames(
            title="Select One or Multiple Android APK Files to Install",
            filetypes=[("Android Package", "*.apk"), ("All Files", "*.*")],
        )
        if not apk_paths:
            return

        apk_list = list(apk_paths)
        self.set_status(f"Batch installing {len(apk_list)} APK(s) onto {self.current_serial}...", "#38bdf8")

        def on_batch_done() -> None:
            self.set_status(f"Completed batch APK installation ({len(apk_list)} package(s)).", "#10b981")
            self.refresh_packages_list()

        BatchApkInstallModal(self, self.adb, self.current_serial, apk_list, on_batch_done)

    def _uninstall_selected_package(self) -> None:
        pkg = self._get_selected_package()
        if not pkg or not self.current_serial:
            return
        if not messagebox.askyesno("Confirm Uninstall", f"Uninstall package '{pkg}' from {self.current_serial}?"):
            return

        def worker() -> None:
            code, out, err = self.adb.run_adb(["uninstall", pkg], serial=self.current_serial, timeout=20.0)
            if code == 0 and "Success" in out:
                self.after(0, lambda: self.set_status(f"Uninstalled {pkg}", "#10b981"))
                self.refresh_packages_list()
            else:
                code2, out2, err2 = self.adb.run_adb(
                    ["shell", "pm", "uninstall", "-k", "--user", "0", pkg], serial=self.current_serial, timeout=20.0
                )
                msg = out2 or err2 or out or err
                self.after(0, lambda: self.set_status(f"Uninstall result for {pkg}: {msg}", "#38bdf8"))
                self.refresh_packages_list()

        threading.Thread(target=worker, daemon=True).start()

    def _force_stop_selected_package(self) -> None:
        pkg = self._get_selected_package()
        if not pkg or not self.current_serial:
            return

        def worker() -> None:
            self.adb.run_adb(["shell", "am", "force-stop", pkg], serial=self.current_serial)
            self.after(0, lambda: self.set_status(f"Force-stopped {pkg}", "#f59e0b"))

        threading.Thread(target=worker, daemon=True).start()

    def _clear_selected_package_data(self) -> None:
        pkg = self._get_selected_package()
        if not pkg or not self.current_serial:
            return
        if not messagebox.askyesno("Clear App Data", f"Wipe all data and cache for '{pkg}'?"):
            return

        def worker() -> None:
            code, out, _ = self.adb.run_adb(["shell", "pm", "clear", pkg], serial=self.current_serial)
            self.after(0, lambda: self.set_status(f"Clear Data ({pkg}): {out}", "#10b981" if code == 0 else "#f43f5e"))

        threading.Thread(target=worker, daemon=True).start()

    def _launch_selected_package(self) -> None:
        pkg = self._get_selected_package()
        if not pkg or not self.current_serial:
            return

        def worker() -> None:
            self.adb.run_adb(
                ["shell", "monkey", "-p", pkg, "-c", "android.intent.category.LAUNCHER", "1"],
                serial=self.current_serial,
            )
            self.after(0, lambda: self.set_status(f"Launched {pkg} on device.", "#10b981"))

        threading.Thread(target=worker, daemon=True).start()

    def _launch_selected_package_in_dex(self) -> None:
        pkg = self._get_selected_package()
        if not pkg:
            return
        self._switch_view(1)
        self.dex_start_app_entry.delete(0, "end")
        self.dex_start_app_entry.insert(0, pkg)
        self.start_dex_desktop_mode(start_package=pkg)

    def _pull_selected_apk(self) -> None:
        pkg = self._get_selected_package()
        if not pkg or not self.current_serial:
            return

        save_dir = filedialog.askdirectory(title="Select Destination Folder for Pulled APK")
        if not save_dir:
            return

        def worker() -> None:
            code, out, _ = self.adb.run_adb(["shell", "pm", "path", pkg], serial=self.current_serial)
            if code == 0 and out:
                first_line = out.splitlines()[0].strip()
                remote_apk = first_line.replace("package:", "").strip()
                local_apk = os.path.join(save_dir, f"{pkg}.apk")
                c2, _, _ = self.adb.run_adb(["pull", remote_apk, local_apk], serial=self.current_serial, timeout=60.0)
                if c2 == 0:
                    self.after(0, lambda: self.set_status(f"Pulled APK to {local_apk}", "#10b981"))
                    return
            self.after(0, lambda: self.set_status(f"Failed to pull APK for {pkg}", "#f43f5e"))

        threading.Thread(target=worker, daemon=True).start()

    # =========================================================================
    # DEVICE HARDWARE & SYSTEM TELEMETRY INFO
    # =========================================================================
    def refresh_device_info(self) -> None:
        serial = self.current_serial
        if not serial:
            return

        def worker() -> None:
            info = self.adb.get_device_info(serial)
            self.after(0, lambda: self._populate_device_info(info))

        threading.Thread(target=worker, daemon=True).start()

    def _populate_device_info(self, info: Dict[str, str]) -> None:
        self.last_device_info = info
        self.info_tree.delete(*self.info_tree.get_children())
        for k, v in info.items():
            self.info_tree.insert("", "end", values=(k, v))

    def _copy_device_info_clipboard(self) -> None:
        info = getattr(self, "last_device_info", {})
        if not info:
            return
        self.clipboard_clear()
        self.clipboard_append(json.dumps(info, indent=2))
        self.set_status("Copied Device Hardware JSON report to clipboard.", "#10b981")

    # =========================================================================
    # PARENT-COUPLED LIFECYCLE WATCHDOG (RULE #6)
    # =========================================================================
    def _cleanup_child_engines(self) -> None:
        self.monitor.running = False
        self.stop_scrcpy_mirror()
        self.stop_dex_desktop_mode()

    def _lifecycle_watchdog_loop(self) -> None:
        while self.monitor.running:
            if not psutil.pid_exists(self.parent_pid):
                self._cleanup_child_engines()
                os._exit(0)
            time.sleep(2.0)

    def _on_close(self) -> None:
        self._cleanup_child_engines()
        self.destroy()


if __name__ == "__main__":
    app = AdbScrcpyStudioApp()
    app.mainloop()
